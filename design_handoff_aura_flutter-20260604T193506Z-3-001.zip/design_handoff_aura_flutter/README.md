# Handoff — AURA Media Player (Flutter)

## Overview

AURA is a personal all-in-one media player for iPhone (Flutter, iOS-first): a built-in
browser that detects and saves media, a local library of music & video, a discovery
feed, a downloads manager, and an immersive full-screen player. The defining idea is
**dynamic colour** — the dominant colour of the current artwork tints the player
background, the floating chrome, and contextual accents, crossfading on every track
change.

Design keywords: **épuré · premium · immersif · dark-first · verre dépoli (frosted
glass) · couleur dynamique · minimal.**

## About this bundle

1. **`flutter/`** — **native Flutter / Dart reference code** for all six screens,
   written to the locked decisions below. It mirrors the prototype 1:1 but has **not
   been run through the Flutter compiler.**
2. **`prototype/`** — the original interactive **HTML/JS/CSS prototype**. This is the
   **visual ground truth**: open `prototype/AURA Media Player.html` in a browser to see
   every screen, interaction, animation, and the live colour extraction. It is a
   *design reference*, not code to ship.
3. **`screenshots/`** — rendered reference of all six screens.

**Your task (Claude Code):** stand up the Flutter app using `flutter/` as the
implementation blueprint and `prototype/` as the pixel reference. Integrate the files
into a real Flutter project, run `flutter pub get`, fix any compile/integration
details, supply real artwork, and wire `PlayerModel` to a real audio engine
(`just_audio` / `video_player`). Reuse the established tokens, components, and patterns —
don't redesign.

## Getting it running

```bash
flutter create aura_media_player          # or use your existing project
# copy flutter/lib/ and flutter/pubspec.yaml into it
flutter pub get
# add real cover images to assets/artwork/<key>.jpg  (keys in lib/data/store.dart)
flutter run
```

Stack chosen (all standard, declared in `pubspec.yaml`):
- **provider** — app + playback state (`PlayerModel`, `DynamicColor`).
- **google_fonts** — Inter (SF Pro substitute, like the prototype).
- **palette_generator** — dominant-colour extraction from artwork.
- **path_drawing** — renders the prototype's exact SVG icon glyphs (`lib/widgets/icons.dart`).

> **Material 3 + custom widgets.** The app uses a Material shell but the look is fully
> custom (dark-first, frosted glass, one accent) — it is intentionally **not** stock
> Material. Keep the custom widgets; lean on Material only for plumbing
> (`Scaffold`, `showModalBottomSheet`, `Navigator`).

## Fidelity

**High-fidelity.** Final colours, typography, spacing, radii, materials, and motion are
all specified here, in `lib/theme/tokens.dart`, and in the prototype. Recreate the UI
pixel-for-pixel. Compare the running app against `screenshots/` and the HTML prototype.

---

## Design tokens  →  `lib/theme/tokens.dart`

### Colour — accent (brand)

| Token | Dark value | Notes |
|---|---|---|
| **accent** | `#FF6E72` | Coral, brightened for dark (base `#FF5A5F`). Exactly **one** accent app-wide. Swap to `#3B86FF` for the blue identity. Expose via a settings provider / `ThemeExtension` if it must be user-switchable. |

### Colour — semantic (iOS dark)

| Role | Token | Dark |
|---|---|---|
| Background | `AppColors.bg` | `#000000` |
| Secondary bg | `AppColors.bg2` | `#1C1C1E` |
| Tertiary bg | `AppColors.bg3` | `#2C2C2E` |
| Label | `AppColors.label` | `#FFFFFF` |
| Secondary label | `AppColors.label2` | white-ish @60% |
| Tertiary label | `AppColors.label3` | @30% |
| Separator | `AppColors.separator` | hairline @55% |
| Success / Error / Warning | — | `#30D158` / `#FF453A` / `#FF9F0A` |

> **Light mode:** the prototype was built dark-only (per the brief). The token class
> holds dark values as consts. To add light mode, promote `AppColors` to a
> `ThemeExtension` with light/dark variants and read it from `Theme.of(context)`.

### Dynamic colour (signature mechanic)  →  `lib/core/dynamic_color.dart`

`DynamicColor` (a `ChangeNotifier`) extracts the dominant colour from the current
artwork via `palette_generator`, then applies the prototype's legibility correction:
- **dominant** — vivid (saturation 0.40–0.72, lightness 0.32–0.50) → chrome tint + halo.
- **ambient** — darkened & desaturated (lightness 0.14) → the wash behind the blurred
  artwork, so overlaid text stays readable.

`RootShell` calls `dyn.update(artProvider(art), art)` whenever the track changes; chrome
and player read `context.watch<DynamicColor>()` and crossfade with `AnimatedContainer`
over `Motion.dynamicColor` (600 ms).

### Typography — Inter (SF Pro substitute) · `AppText`

Display/titles 28–34 w700 tracking −0.4…−0.6 · track title 16–17 w600 · subtitle 14–15
w400 · section header 13 w600 +0.4 UPPERCASE · timestamps mono. On a real iOS build you
may switch Inter → the system font (San Francisco) by replacing the `GoogleFonts.inter`
calls in `AppText` with `TextStyle(fontFamily: '.SF Pro Text')` / default.

### Spacing · radii · motion

`Space` (base-4: side margins 16, large-title 20) · `R` (xs8 · sm10 · md12 · art15 ·
lg20 · pill) · `Motion` (fast 160 ms, base 240 ms, dynamicColor 600 ms; `ease` /
`easeOut` / `spring` curves). One shadow only — `artworkShadow`, for artwork. Frosted
glass = `BackdropFilter(ImageFilter.blur)` + a translucent fill (see `Glass`).

### Icons  →  `lib/widgets/icons.dart`

`AppIcon('name', size:…, color:…)` renders the **same SVG path data as the prototype**
through `path_drawing`. Outline glyphs are stroked, `*Fill` glyphs filled (active
states). SF Symbol equivalents are noted in comments — swap to `CupertinoIcons` or a
custom font later if preferred.

---

## Screens

> file → prototype reference → screenshot

### 1 · Fused MiniPlayer + TabBar  →  `lib/screens/chrome.dart` · `screenshots/05-chrome.png`
A single floating frosted block (`BackdropFilter`, radius 22) tinted by the dynamic
colour. Mini-player (artwork 44 · title/artist · pause · forward · 2-pt progress line at
the bottom) above a 4-tab bar (Browser · Bibliothèque · Découverte · Player; active icon
filled + accent; accent dot badges Bibliothèque while downloading). Tap → player sheet ·
swipe ←/→ skips.

### 2 · Full-screen Player  →  `lib/screens/player_screen.dart` (+ `player_subviews.dart`) · `screenshots/03-player.png`
Background = blurred artwork (`AnimatedSwitcher` + `BackdropFilter`, crossfades on track
change) + dark veil + dynamic ambient wash. Header (`chevronDown` glass · centred context
· `ellipsis`). Crisp artwork centred, radius 15, `artworkShadow`, **scales 1.0 ↔ 0.82**
on play/pause (`AnimatedScale`, spring). Title 27 + artist + heart. Scrubber (4-pt /
11-pt thumb) + mono timestamps. Five controls: shuffle · backward · **play/pause 70-pt
white circle** · forward · repeat. Volume slider + airplay. Footer tabs **Paroles /
File d'attente** swap lyrics (current line highlighted) or the queue into the centre.

### 3 · Browser + interception  →  `lib/screens/browser_screen.dart` · `screenshots/06-browser.png` + `07-intercept.png`
Custom nav bar (back · forward · URL capsule w/ lock · refresh · home). Home = 4-up
shortcut grid + recents. On media detection a **`showModalBottomSheet`** rises:
"DÉTECTÉ · {SOURCE}" eyebrow, **Lire maintenant** primary pill, **Audio / Vidéo**
secondary pair, **Partager le lien** tertiary. (`InterceptSheet`.)

### 4 · Downloads  →  `lib/screens/downloads_screen.dart` · `screenshots/04-downloads.png`
Pushed from the Bibliothèque downloads tool (`Navigator.push`). Sections EN COURS /
TERMINÉS. Each row: artwork 40 · title · sub-state · **`ProgressRing`** (queued/down­
loading/done/error). Non-technical error copy: "Échec — on réessaiera tout seul. Vérifie
ta connexion." Tab badge mirrors the active count.

### 5 · Bibliothèque  →  `lib/screens/library_screen.dart` · `screenshots/01-library.png`
Large title + tools (downloads `HeaderTool` w/ badge · sort · filter). `Segmented`
(Tout · Musique · Vidéos · Playlists). 64-pt `TrackCell` list (artwork 52 · video badge ·
duration · ellipsis menu). Playlists: `Mosaic` cells + "Créer une playlist" (accent).

### 6 · Découverte  →  `lib/screens/discovery_screen.dart` · `screenshots/02-discovery.png`
Three states by search text + selection: **empty** (recents chips, Tendances carousel
with rank badges, popular-artist bubbles) → **results** (grouped by source, staggered via
`_StaggeredItem`; row ellipsis → options sheet) → **artist page** (`ArtistPageView`:
parallax header via a scroll-driven `Transform.translate`, expandable bio, top tracks,
discography grid, similar artists).

---

## State management  →  Provider

- **`PlayerModel`** (`lib/data/player_model.dart`) — `queue`, `index`, `isPlaying`,
  `progress` (0..1), `volume`, `shuffle`, `repeatOn`, liked set, `contextLabel`. A timer
  fakes playback — **replace with a real audio engine** and bind `progress` to its
  position stream, `isPlaying` to its play state.
- **`DynamicColor`** (`lib/core/dynamic_color.dart`) — `dominant` + `ambient`, updated
  on track change.
- **`DataStore`** (`lib/data/store.dart`) — sample catalogue; replace with your data /
  network layer.
- **`RootShell`** (`lib/main.dart`) — owns the current tab, opens the player sheet, shows
  toasts (`OverlayEntry`), and keeps `DynamicColor` synced.

## Assets

- **Artwork** — the prototype *generates* abstract covers at runtime
  (`prototype/src/artwork.js`) only so its in-browser colour sampling had same-origin
  images. **In the app, supply real images** in `assets/artwork/<key>.jpg` — keys are in
  `lib/data/store.dart` (`distorted`, `nightswim`, …). `artProvider(key)` in
  `lib/widgets/artwork.dart` centralises that mapping (used by both the views and the
  colour extractor). `Artwork` shows an initial-letter placeholder if an image is missing.
- **Icons** — custom glyphs (no asset needed). **Fonts** — Inter via `google_fonts` at
  runtime (no bundled files); to ship offline, bundle Inter and declare it in `pubspec`.

## Constraints (from the brief)

Native Flutter, minimal well-chosen deps · dark-first (light mode via ThemeExtension if
needed) · respect text scaling (avoid hard-locked font sizes where possible) · hit
targets ≥ 44×44 · frosted glass via `BackdropFilter` + blur · **do not copy Apple
Music** — keep AURA's own coral + frosted glass + dynamic-colour identity.

## Files

```
design_handoff_aura_flutter/
├── README.md                  ← this brief (self-sufficient)
├── flutter/
│   ├── pubspec.yaml
│   └── lib/
│       ├── main.dart                    ← entry + RootShell (START HERE)
│       ├── theme/tokens.dart            ← colour · type · spacing · radii · motion
│       ├── core/dynamic_color.dart      ← dominant-colour extraction
│       ├── data/
│       │   ├── models.dart · store.dart · player_model.dart
│       ├── widgets/
│       │   ├── icons.dart · artwork.dart · buttons.dart
│       │   ├── scrubber.dart · progress_ring.dart · common.dart
│       └── screens/
│           ├── chrome.dart · player_screen.dart · player_subviews.dart
│           ├── library_screen.dart · downloads_screen.dart
│           ├── browser_screen.dart · discovery_screen.dart
├── prototype/                 ← interactive visual ground truth (open the .html)
└── screenshots/               ← rendered reference of all six screens
```
