// data/player_model.dart
//
// Playback state as a ChangeNotifier (Provider). A timer advances
// [progress] to mimic playback — replace with a real audio engine
// (just_audio / video_player) and bind progress to its position stream.

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'models.dart';

class PlayerModel extends ChangeNotifier {
  final List<Track> queue;
  int index;
  bool isPlaying;
  double progress; // 0..1
  double volume;
  bool shuffle;
  bool repeatOn;
  final Set<String> _liked;
  String contextLabel;

  Timer? _ticker;

  PlayerModel({
    required this.queue,
    this.index = 0,
    this.isPlaying = true,
    this.progress = 0.29,
    this.volume = 0.62,
    this.shuffle = false,
    this.repeatOn = false,
    Set<String>? liked,
    this.contextLabel = 'BIBLIOTHÈQUE · NUITS FEUTRÉES',
  }) : _liked = liked ?? {'goldhour'} {
    _restartTicker();
  }

  Track get current => queue[index];
  bool get isLiked => _liked.contains(current.id);
  String get elapsedText => Track.mmss(current.duration * progress);
  String get remainingText => Track.mmss(current.duration * (1 - progress));

  void _restartTicker() {
    _ticker?.cancel();
    if (!isPlaying) return;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      progress += 1 / current.duration;
      if (progress >= 1) {
        index = (index + 1) % queue.length;
        progress = 0;
      }
      notifyListeners();
    });
  }

  void togglePlay() {
    isPlaying = !isPlaying;
    _restartTicker();
    notifyListeners();
  }

  void toggleLike() {
    _liked.contains(current.id) ? _liked.remove(current.id) : _liked.add(current.id);
    notifyListeners();
  }

  void next() {
    index = (index + 1) % queue.length;
    progress = 0;
    notifyListeners();
  }

  void previous() {
    if (progress > 0.04) {
      progress = 0;
    } else {
      index = (index - 1 + queue.length) % queue.length;
      progress = 0;
    }
    notifyListeners();
  }

  void jumpTo(int i) {
    index = i % queue.length;
    progress = 0;
    notifyListeners();
  }

  void play(Track t) {
    final i = queue.indexWhere((q) => q.id == t.id);
    if (i >= 0) {
      index = i;
      progress = 0;
      isPlaying = true;
      _restartTicker();
      notifyListeners();
    }
  }

  void seek(double v) {
    progress = v.clamp(0.0, 1.0);
    notifyListeners();
  }

  void setVolume(double v) {
    volume = v.clamp(0.0, 1.0);
    notifyListeners();
  }

  void toggleShuffle() {
    shuffle = !shuffle;
    notifyListeners();
  }

  void toggleRepeat() {
    repeatOn = !repeatOn;
    notifyListeners();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
