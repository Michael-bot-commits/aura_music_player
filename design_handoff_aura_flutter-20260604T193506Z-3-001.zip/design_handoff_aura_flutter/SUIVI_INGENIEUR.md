# AURA MEDIA PLAYER — JOURNAL DE SUIVI INGÉNIEUR
# Flutter · VSCode · Ubuntu
# Ce que TU fais · Ce que CLAUDE CODE fait · Ce que tu valides

---

## LÉGENDE

[TOI]         → Action manuelle requise dans le terminal ou VSCode
[CC]          → Claude Code génère ou modifie le code
[VALIDER]     → Tu testes et confirmes avant de continuer
[JAMAIS CC]   → Claude Code ne peut pas faire ça — tu dois le faire toi-même

---

## PRÉ-REQUIS — À INSTALLER SUR TON UBUNTU AVANT DE COMMENCER

### [TOI] Installer Flutter SDK
```bash
# Méthode recommandée via snap
sudo snap install flutter --classic
flutter --version   # vérifier >= 3.19.0

# Ou via téléchargement manuel
# https://docs.flutter.dev/get-started/install/linux
```

### [TOI] Installer l'extension Flutter dans VSCode
1. Ouvrir VSCode
2. Extensions (Ctrl+Shift+X)
3. Chercher "Flutter" → installer l'extension officielle Dart/Flutter
4. Chercher "Dart" → installer si pas déjà inclus

### [TOI] Vérifier l'environnement
```bash
flutter doctor
# Résoudre tous les problèmes signalés avant de commencer
```

### [TOI] Pour iOS (nécessite un Mac ou simulateur)
Si tu veux tester sur iOS depuis Ubuntu :
- Tu auras besoin d'un Mac avec Xcode pour compiler iOS
- Sur Ubuntu, tu peux développer et tester sur Android d'abord
- Pour un vrai iPhone : utilise un Mac comme machine de build

### [TOI] Pour Android sur Ubuntu
```bash
# Installer Android Studio ou juste le CLI
sudo snap install android-studio --classic
# Ouvrir Android Studio → SDK Manager → installer un SDK Android
# Créer un émulateur via AVD Manager
flutter emulators --launch <nom_emulateur>
```

---

## ÉTAPE 1 — SETUP PROJET FLUTTER
**Objectif : projet qui compile, structure en place**

### [TOI] Créer le projet Flutter
```bash
flutter create aura_media_player \
  --org com.tonnom \
  --platforms ios,android \
  --description "AURA — personal all-in-one media player"
cd aura_media_player
code .   # ouvrir dans VSCode
```

### [TOI] Copier les fichiers du handoff
```bash
# Depuis le dossier design_handoff_aura_flutter/
cp -r flutter/lib/ lib/
cp flutter/pubspec.yaml .
mkdir -p assets/artwork
```

### [TOI] Ajouter des images placeholder dans assets/artwork/
Pour que l'app compile avec les clés du DataStore :
Créer ou trouver 12 images JPG nommées exactement :
```
distorted.jpg · nightswim.jpg · goldhour.jpg · violetstatic.jpg
coralcoast.jpg · magenta.jpg · amberdusk.jpg · indigowave.jpg
fernyard.jpg · slatebloom.jpg · rosequartz.jpg · tealglass.jpg
```
Note : images temporaires pour cette étape.
Les vraies pochettes viendront de MusicBrainz à l'étape 12.

### [CC] Installer les dépendances et corriger les erreurs
```bash
flutter pub get
flutter analyze   # voir les erreurs
```
Demander à Claude Code :
"Corrige les erreurs de compilation dans les fichiers lib/ copiés
du handoff. Ne modifie pas tokens.dart, dynamic_color.dart, icons.dart."

### [VALIDER] ✅ Critères de validation étape 1
- [ ] `flutter pub get` sans erreur
- [ ] `flutter run` compile et lance l'app
- [ ] Les 4 tabs s'affichent (Browser · Bibliothèque · Découverte · Player)
- [ ] La couleur accent coral (#FF6E72) est visible sur les éléments actifs
- [ ] FusedChrome (mini-player + tabbar) flotte en bas
- [ ] Le dark mode s'affiche correctement
- [ ] `flutter analyze` → 0 erreur critique

---

## ÉTAPE 2 — INTÉGRATION FICHIERS DESIGN
**Objectif : tous les écrans visuellement fidèles aux screenshots/**

### [CC] Corriger les erreurs de compilation restantes
Claude Code corrige imports, types, initialisers.
Il ne modifie PAS :
- `lib/theme/tokens.dart`
- `lib/core/dynamic_color.dart`
- `lib/widgets/icons.dart`
- Les valeurs numériques (tailles, rayons, espacements)
- Les couleurs définies

### [VALIDER] ✅ Critères de validation étape 2
Comparer chaque écran avec screenshots/ :
- [ ] screenshots/01-library.png → LibraryScreen identique
- [ ] screenshots/02-discovery.png → DiscoveryScreen identique
- [ ] screenshots/03-player.png → PlayerScreen identique
- [ ] screenshots/04-downloads.png → DownloadsScreen identique
- [ ] screenshots/05-chrome.png → FusedChrome identique
- [ ] screenshots/06-browser.png → BrowserScreen identique
- [ ] screenshots/07-intercept.png → InterceptSheet identique
- [ ] screenshots/08-discovery-results.png → résultats groupés identiques
- [ ] screenshots/09-artist.png → ArtistPageView identique
- [ ] Ouvrir prototype HTML pour comparaison pixel-level

---

## ÉTAPE 3 — CÂBLAGE JUST_AUDIO
**Objectif : lecture audio réelle, progression en temps réel**

### [TOI] Ajouter just_audio dans pubspec.yaml
```yaml
just_audio: ^0.9.36
audio_session: ^0.1.18
```
```bash
flutter pub get
```

### [CC] Créer lib/core/audio_manager.dart
Câbler just_audio au PlayerModel.
Remplacer le Timer par les streams just_audio.

### [CC] Modifier PlayerModel
Accepter AudioManager comme dépendance.
togglePlay/next/previous/seek appellent le vrai player.

### [VALIDER] ✅ Critères de validation étape 3
- [ ] Tap sur une piste → lecture audio réelle démarre
- [ ] La barre de progression dans le mini-player avance en temps réel
- [ ] Tap play/pause → l'audio s'arrête et reprend
- [ ] Tap suivant → piste suivante démarre
- [ ] AnimatedScale artwork fonctionne (1.0 ↔ 0.82) au play/pause
- [ ] Timestamps corrects (elapsed / -remaining)

---

## ÉTAPE 4 — BACKGROUND AUDIO + CONTROL CENTER iOS
**Objectif : audio identique à Apple Music ou Spotify**

### [TOI] Ajouter just_audio_background dans pubspec.yaml
```yaml
just_audio_background: ^0.0.1-beta.10
```
```bash
flutter pub get
```

### [JAMAIS CC] Modifier ios/Runner/Info.plist
Claude Code ne peut pas modifier les fichiers iOS natifs.
Tu dois ajouter manuellement dans Info.plist :
```xml
<key>UIBackgroundModes</key>
<array>
  <string>audio</string>
  <string>fetch</string>
</array>
```

### [JAMAIS CC] Modifier android/app/src/main/AndroidManifest.xml
Ajouter manuellement :
```xml
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
```

### [CC] Créer lib/core/background_audio.dart
Initialiser just_audio_background dans main().

### [VALIDER] ✅ Critères de validation étape 4
- [ ] Lancer une piste → verrouiller l'écran → audio continue
- [ ] Écran de verrouillage affiche : pochette · titre · artiste
- [ ] Boutons play/pause/suivant/précédent depuis l'écran verrouillé
- [ ] Quitter l'app → audio continue en arrière-plan
- [ ] Control Center iOS affiche pochette et contrôles fonctionnels

---

## ÉTAPE 5 — PLAYER PLEIN ÉCRAN COMPLET
**Objectif : player plein écran 100% fonctionnel**

### [CC] Valider et compléter PlayerScreen
Tous les éléments câblés avec vrai PlayerModel.

### [VALIDER] ✅ Critères de validation étape 5
- [ ] Tap mini-player → player s'ouvre (sheet full height)
- [ ] Swipe down → player se ferme
- [ ] AnimatedSwitcher backdrop crossfade au changement de piste
- [ ] DynamicColor change avec chaque pochette
- [ ] Scrubber drag fonctionne (seek réel)
- [ ] Shuffle/Repeat toggles fonctionnent
- [ ] Heart toggle fonctionne
- [ ] Tab Paroles affiche le texte
- [ ] Tab File d'attente affiche les prochaines pistes
- [ ] Volume slider fonctionnel

---

## ÉTAPE 6 — BIBLIOTHÈQUE LOCALE RÉELLE
**Objectif : lire les vrais fichiers audio/vidéo de l'appareil**

### [CC] Lire les fichiers dans app documents
Utiliser `path_provider` pour le dossier documents.
Lister les fichiers .mp3, .m4a, .mp4, .mov.
Convertir en Track.

### [CC] Alimenter LibraryScreen avec données réelles

### [VALIDER] ✅ Critères de validation étape 6
- [ ] La bibliothèque affiche les fichiers audio de l'appareil
- [ ] Filtres Musique / Vidéos / Playlists fonctionnent
- [ ] Tap sur une piste → lecture démarre
- [ ] Les vidéos ont le badge videoBadge sur leur artwork
- [ ] La piste en cours est en tint accent dans la liste

---

## ÉTAPE 7 — BASE DE DONNÉES SQFLITE
**Objectif : persistance des données entre sessions**

### [TOI] Ajouter sqflite dans pubspec.yaml
```yaml
sqflite: ^2.3.2
path: ^1.9.0
path_provider: ^2.1.2
```
```bash
flutter pub get
```

### [CC] Créer lib/data/database.dart
Tables : tracks + playlists + playlist_tracks

### [CC] Remplacer progressivement DataStore
DataStore reste pour les données sample de test.
SQLite prend en charge les vraies données.

### [VALIDER] ✅ Critères de validation étape 7
- [ ] Fermer et rouvrir l'app → bibliothèque toujours présente
- [ ] Créer une playlist → elle persiste après restart
- [ ] Les téléchargements apparaissent après restart
- [ ] playCount et lastPlayed mémorisés

---

## ÉTAPE 8 — BROWSER AVEC WEBVIEW_FLUTTER RÉEL
**Objectif : vrai navigateur web avec détection de contenu**

### [TOI] Ajouter webview_flutter dans pubspec.yaml
```yaml
webview_flutter: ^4.7.0
```
```bash
flutter pub get
```

### [JAMAIS CC] Configurer iOS pour WebView
Dans ios/Runner/Info.plist ajouter :
```xml
<key>NSAppTransportSecurity</key>
<dict>
  <key>NSAllowsArbitraryLoads</key><true/>
</dict>
```

### [CC] Remplacer la simulation par WebViewController réel
Injection JavaScript pour détecter <video> et <audio>.
InterceptSheet déclenché par vraie détection.

### [VALIDER] ✅ Critères de validation étape 8
- [ ] Ouvrir YouTube dans le browser → la page charge
- [ ] Lancer une vidéo YouTube → InterceptSheet apparaît
- [ ] "Lire maintenant" → la vidéo/audio joue dans l'app
- [ ] Navigation back/forward fonctionne
- [ ] Bouton home → retour à l'accueil avec raccourcis
- [ ] Les 4 raccourcis (YouTube/SoundCloud/Vimeo/Instagram) fonctionnent

---

## ÉTAPE 9 — BACKEND SERVICE + DOWNLOAD MANAGER
**Objectif : téléchargement complet câblé**

### [JAMAIS CC] Démarrer le backend Python sur ton Mac/serveur
Claude Code ne peut pas démarrer des processus externes.
Instructions dans le prompt backend Python (partie 2).

### [TOI] Configurer l'URL du backend dans l'app
Ajouter un écran Settings minimal avec champ URL backend.
Default : `http://localhost:8000`

### [CC] Créer lib/services/backend_service.dart
Tous les endpoints définis dans le prompt.

### [CC] Créer lib/services/download_manager.dart
Queue + polling + gestion erreur + badge TabBar.

### [VALIDER] ✅ Critères de validation étape 9
- [ ] "Télécharger audio" → toast "Téléchargement lancé"
- [ ] DownloadsScreen affiche le download avec ProgressRing
- [ ] L'anneau de progression avance en temps réel
- [ ] À la fin : checkCircle vert · fichier dans la bibliothèque
- [ ] Badge accent sur l'onglet Bibliothèque pendant le téléchargement
- [ ] Message non technique si backend inaccessible :
      "Échec — on réessaiera tout seul. Vérifie ta connexion."
- [ ] "Télécharger vidéo" → fichier MP4 dans la bibliothèque

---

## ÉTAPE 10 — DEEZER API
**Objectif : découverte musicale avec vrai catalogue**

### [JAMAIS CC] Obtenir les clés API (voir tableau en bas de page)

### [CC] Créer lib/services/deezer_service.dart

### [CC] Brancher DiscoveryScreen à Deezer
Remplacer DataStore.groupedResults par vraies données.

### [VALIDER] ✅ Critères de validation étape 10
- [ ] Taper "Travis Scott" → résultats Deezer s'affichent
- [ ] Résultats apparaissent en staggered (fade + rise)
- [ ] Ellipsis → dialog options
- [ ] "Aperçu 30s" → lecture de 30 secondes
- [ ] Fiche artiste avec vraie photo et vraie bio
- [ ] Discographie réelle de l'artiste

---

## ÉTAPE 11 — SOUNDCLOUD + JAMENDO + LAST.FM

### [CC] Créer soundcloud_service.dart, jamendo_service.dart, lastfm_service.dart

### [VALIDER] ✅ Critères de validation étape 11
- [ ] Résultats groupés Deezer · SoundCloud · Jamendo
- [ ] Lecture complète d'un titre SoundCloud public
- [ ] Téléchargement d'un titre Jamendo (libre de droits)
- [ ] Biographie artiste via Last.fm
- [ ] Artistes similaires enrichis

---

## ÉTAPE 12 — POCHETTES AUTOMATIQUES

### [TOI] Ajouter cached_network_image dans pubspec.yaml
```yaml
cached_network_image: ^3.3.1
```
```bash
flutter pub get
```

### [CC] Créer lib/services/musicbrainz_service.dart
Logique priorité : MusicBrainz → miniature YouTube → placeholder.

### [VALIDER] ✅ Critères de validation étape 12
- [ ] Chaque piste a une pochette (aucun placeholder vide)
- [ ] La pochette s'affiche dans le Control Center
- [ ] Relancer l'app → pochettes en cache (pas de rechargement)
- [ ] Piste YouTube → miniature YouTube si pas de MusicBrainz

---

## ÉTAPE 13 — PAROLES

### [CC] Créer lib/services/lrclib_service.dart + genius_service.dart

### [CC] Brancher LyricsView avec vraies paroles

### [VALIDER] ✅ Critères de validation étape 13
- [ ] Tab Paroles dans le player → paroles s'affichent
- [ ] La ligne active avance avec la musique
- [ ] Si pas de paroles → tab Paroles masqué proprement
- [ ] LRCLIB en priorité · Genius en fallback

---

## ÉTAPE 14 — POLISH ET STABILISATION

### [CC] Mode offline
L'app fonctionne sans réseau pour lecture locale.
Messages clairs si réseau requis.

### [CC] Animations finales
Vérifier toutes les transitions contre le prototype HTML.

### [VALIDER] ✅ Critères de validation étape 14
- [ ] Mode avion → lecture locale fonctionne
- [ ] Mode avion → message clair si réseau requis
- [ ] Toutes les animations correspondent au prototype HTML
- [ ] Aucune régression sur les étapes précédentes
- [ ] `flutter analyze` → 0 erreur

---

## CE QUE CLAUDE CODE NE PEUT JAMAIS FAIRE
(tu dois le faire toi-même)

```
[JAMAIS CC] Créer le projet Flutter (flutter create)
[JAMAIS CC] Modifier ios/Runner/Info.plist (fichiers iOS natifs)
[JAMAIS CC] Modifier android/AndroidManifest.xml
[JAMAIS CC] Modifier les fichiers Gradle Android
[JAMAIS CC] Démarrer le backend Python
[JAMAIS CC] Configurer Tailscale sur ton système
[JAMAIS CC] Obtenir les clés API externes
[JAMAIS CC] Ajouter de vraies images dans assets/artwork/
[JAMAIS CC] Lancer `flutter run` (tu fais ça toi dans le terminal)
[JAMAIS CC] Publier sur App Store ou Google Play
[JAMAIS CC] Configurer les comptes développeur Apple / Google
[JAMAIS CC] Résoudre les problèmes signalés par `flutter doctor`
```

---

## COMMANDES UTILES AU QUOTIDIEN (VSCode / Ubuntu)

```bash
# Lancer l'app
flutter run

# Lancer sur un device spécifique
flutter devices                  # lister les appareils disponibles
flutter run -d <device_id>

# Hot reload (dans le terminal flutter run)
r   → hot reload (rapide, garde le state)
R   → hot restart (plus lent, remet le state à zéro)
q   → quitter

# Analyser le code
flutter analyze

# Formater le code
dart format lib/

# Mettre à jour les dépendances
flutter pub upgrade

# Nettoyer le build
flutter clean && flutter pub get

# Build release iOS (nécessite Mac)
flutter build ios --release

# Build release Android
flutter build apk --release
# ou
flutter build appbundle --release
```

---

## CLÉS API À OBTENIR AVANT LES ÉTAPES 10-13
(tu crées les comptes toi-même, tu donnes les clés à Claude Code)

| Service | URL inscription | Gratuit | Quand |
|---|---|---|---|
| Deezer API | https://developers.deezer.com | ✅ | Étape 10 |
| Last.fm API | https://www.last.fm/api | ✅ | Étape 11 |
| SoundCloud | https://developers.soundcloud.com | ✅ | Étape 11 |
| Jamendo | https://developer.jamendo.com | ✅ | Étape 11 |
| Genius API | https://genius.com/api-clients | ✅ | Étape 13 |
| LRCLIB | Pas de clé requise | ✅ | Étape 13 |
| MusicBrainz | Pas de clé requise | ✅ | Étape 12 |

---

## CHECKLIST FINALE AVANT DE DIRE "C'EST FINI"

```
FONCTIONNALITÉS
[ ] Lecture audio locale fonctionne
[ ] Lecture vidéo locale fonctionne
[ ] Lecture vidéo en mode audio (arrière-plan) fonctionne
[ ] Background audio (écran verrouillé) fonctionne
[ ] Control Center identique à Apple Music
[ ] Browser navigue sur de vrais sites
[ ] Interception de contenu déclenche l'InterceptSheet
[ ] Téléchargement audio via yt-dlp fonctionne
[ ] Téléchargement vidéo via yt-dlp fonctionne
[ ] Le fichier téléchargé apparaît dans la bibliothèque
[ ] Recherche Deezer retourne de vrais résultats
[ ] Aperçu 30s Deezer fonctionne
[ ] Paroles s'affichent dans le player
[ ] Playlists créées persistent après restart

DESIGN
[ ] Tous les écrans identiques aux screenshots/
[ ] DynamicColor change avec chaque pochette
[ ] Crossfade backdrop player au changement de piste
[ ] Toutes les animations correspondent au prototype HTML
[ ] Dark mode parfait
[ ] Animations staggered dans les résultats de recherche
[ ] Parallax header artiste fonctionne

QUALITÉ
[ ] flutter analyze → 0 erreur
[ ] Aucun crash en usage normal
[ ] Mode offline dégradé proprement
[ ] Performance fluide (60fps) sur device réel
[ ] `flutter run --profile` → pas de jank visible
```
