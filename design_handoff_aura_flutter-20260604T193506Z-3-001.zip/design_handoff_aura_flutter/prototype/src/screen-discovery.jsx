/* ============================================================
   screen-discovery.jsx — Découverte. three states:
   empty (recents/trending/artists) → grouped results → artist page.
   Exports: DiscoveryScreen
   ============================================================ */

function Chip({ children, onClick }) {
  return (
    <button className="press" onClick={() => { haptic('light'); onClick && onClick(); }}
      style={{ border: 'none', background: 'var(--fill-3)', color: 'var(--label)', cursor: 'pointer',
        height: 34, padding: '0 14px', borderRadius: 'var(--r-pill)', fontSize: 14, fontWeight: 500,
        fontFamily: 'var(--font)', whiteSpace: 'nowrap' }}>{children}</button>
  );
}

function TrendCard({ track, rank, onPlay }) {
  return (
    <div className="press" onClick={() => onPlay(track)} style={{ width: 150, flexShrink: 0, cursor: 'pointer' }}>
      <div style={{ position: 'relative' }}>
        <Art id={track.art} size={150} radius={12} shadow />
        <div style={{ position: 'absolute', left: 8, top: 8, width: 24, height: 24, borderRadius: 7,
          background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', fontSize: 13, fontWeight: 700, color: '#fff' }}>{rank}</div>
      </div>
      <div style={{ fontSize: 15, fontWeight: 600, marginTop: 8, color: 'var(--label)', whiteSpace: 'nowrap',
        overflow: 'hidden', textOverflow: 'ellipsis' }}>{track.title}</div>
      <div style={{ fontSize: 13, color: 'var(--label-2)', whiteSpace: 'nowrap', overflow: 'hidden',
        textOverflow: 'ellipsis' }}>{track.artist}</div>
    </div>
  );
}

function ArtistBubble({ a, onClick, size = 92 }) {
  return (
    <div className="press" onClick={() => onClick && onClick(a)} style={{ width: size, flexShrink: 0, textAlign: 'center', cursor: 'pointer' }}>
      <img src={window.ARTWORKS[a.art]} alt="" style={{ width: size, height: size, borderRadius: '50%', objectFit: 'cover' }} />
      <div style={{ fontSize: 13, fontWeight: 600, marginTop: 8, color: 'var(--label)', whiteSpace: 'nowrap',
        overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.name}</div>
      {a.listeners && <div style={{ fontSize: 11.5, color: 'var(--label-2)' }}>{a.listeners}</div>}
    </div>
  );
}

// ── options sheet for discovery results ──
function OptionsSheet({ track, onClose, onPlay, onDownload }) {
  const rows = [
    { icon: 'playCircle', label: 'Aperçu 30 s', action: () => onPlay(track) },
    { icon: 'globe', label: 'Écouter sur YouTube Music', action: onClose },
    { icon: 'download', label: 'Télécharger audio', action: () => onDownload('audio') },
    { icon: 'video', label: 'Télécharger vidéo', action: () => onDownload('vidéo') },
  ];
  return (
    <div className="enter-fade" style={{ position: 'absolute', inset: 0, zIndex: 70, display: 'flex', flexDirection: 'column',
      justifyContent: 'flex-end' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.4)' }} />
      <div className="enter-sheet" style={{ position: 'relative', background: 'var(--bg-2)', borderRadius: '22px 22px 0 0',
        padding: '0 0 28px' }}>
        <Handle />
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 18px 14px' }}>
          <Art id={track.art} size={46} radius={9} />
          <div><div style={{ fontSize: 16, fontWeight: 600 }}>{track.title}</div>
            <div style={{ fontSize: 13, color: 'var(--label-2)' }}>{track.artist}</div></div>
        </div>
        {rows.map((r, i) => (
          <button key={i} className="press" onClick={r.action} style={{ width: '100%', border: 'none',
            background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 20px', color: 'var(--label)', fontFamily: 'var(--font)', fontSize: 16,
            borderTop: '0.5px solid var(--separator)' }}>
            <Icon name={r.icon} size={20} color="var(--accent)" />{r.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function ArtistPage({ data, onBack, onPlay, onArtist }) {
  const [scroll, setScroll] = React.useState(0);
  const [expand, setExpand] = React.useState(false);
  return (
    <div className="noscroll" onScroll={(e) => setScroll(e.target.scrollTop)}
      style={{ height: '100%', overflowY: 'auto', paddingBottom: 168 }}>
      {/* parallax header */}
      <div style={{ position: 'relative', height: 320, overflow: 'hidden' }}>
        <img src={window.ARTWORKS[data.art]} alt="" style={{ position: 'absolute', inset: 0, width: '100%',
          height: '100%', objectFit: 'cover', transform: `translateY(${scroll * 0.4}px) scale(1.1)`,
          filter: 'saturate(120%)' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0.4) 0%, transparent 40%, var(--bg) 100%)' }} />
        <div style={{ position: 'absolute', top: 6, left: 12 }}>
          <IconBtn icon="chevronLeft" glyph={22} onClick={onBack} />
        </div>
        <div style={{ position: 'absolute', left: 20, bottom: 16, right: 20 }}>
          <h1 style={{ margin: 0, fontSize: 38, fontWeight: 700, letterSpacing: -0.8, color: '#fff' }}>{data.name}</h1>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 2 }}>{data.monthly}</div>
        </div>
      </div>

      <div style={{ padding: '16px 20px 0' }}>
        {/* actions */}
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <PrimaryBtn icon="play" onClick={() => onPlay(data.top[0])} style={{ flex: 1, height: 48 }}>Lire</PrimaryBtn>
          <SecondaryBtn icon="shuffle" onClick={() => onPlay(data.discography[2])} style={{ height: 48, width: 48, padding: 0 }} />
          <SecondaryBtn icon="plus" onClick={() => {}} style={{ height: 48, width: 48, padding: 0 }} />
        </div>

        {/* bio */}
        <p onClick={() => setExpand(!expand)} style={{ fontSize: 15, lineHeight: 1.5, color: 'var(--label-2)',
          margin: '20px 0 4px', cursor: 'pointer',
          display: '-webkit-box', WebkitLineClamp: expand ? 'unset' : 3, WebkitBoxOrient: 'vertical',
          overflow: 'hidden' }}>{data.bio}</p>
        <button onClick={() => setExpand(!expand)} style={{ border: 'none', background: 'none', color: 'var(--accent)',
          fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font)', padding: 0,
          whiteSpace: 'nowrap', marginTop: 4 }}>
          {expand ? 'Réduire' : 'Lire la suite'}</button>
      </div>

      {/* top tracks */}
      <div style={{ marginTop: 24 }}>
        <SectionHeader>Titres populaires</SectionHeader>
        {data.top.map((t, i) => (
          <div key={t.id} className="press" onClick={() => onPlay(t)} style={{ display: 'flex', alignItems: 'center',
            gap: 12, padding: '8px 16px', cursor: 'pointer' }}>
            <span className="mono" style={{ width: 18, fontSize: 14, color: 'var(--label-3)', textAlign: 'center' }}>{i + 1}</span>
            <Art id={t.art} size={44} radius={8} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--label)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.title}</div>
              <div style={{ fontSize: 12.5, color: 'var(--label-2)' }}>{t.plays} écoutes</div>
            </div>
            <Icon name="ellipsis" size={18} color="var(--label-2)" />
          </div>
        ))}
      </div>

      {/* discography grid */}
      <div style={{ marginTop: 24 }}>
        <SectionHeader>Discographie</SectionHeader>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, padding: '0 16px' }}>
          {data.discography.map((t) => (
            <div key={t.id} className="press" onClick={() => onPlay(t)} style={{ cursor: 'pointer' }}>
              <Art id={t.art} size="100%" radius={10} style={{ width: '100%', aspectRatio: '1', height: 'auto' }} />
              <div style={{ fontSize: 12.5, fontWeight: 600, marginTop: 6, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.album}</div>
            </div>
          ))}
        </div>
      </div>

      {/* similar */}
      <div style={{ marginTop: 24 }}>
        <SectionHeader>Artistes similaires</SectionHeader>
        <div className="noscroll" style={{ display: 'flex', gap: 18, overflowX: 'auto', padding: '0 16px 4px' }}>
          {data.similar.map((a) => <ArtistBubble key={a.name} a={a} size={80} onClick={onArtist} />)}
        </div>
      </div>
    </div>
  );
}

function DiscoveryScreen({ onPlay, onDownload }) {
  const { discovery } = window.DATA;
  const [q, setQ] = React.useState('');
  const [artist, setArtist] = React.useState(null);
  const [menu, setMenu] = React.useState(null);

  if (artist) {
    return <>
      <ArtistPage data={discovery.artistPage} onBack={() => setArtist(null)} onPlay={onPlay}
        onArtist={() => {}} />
    </>;
  }

  const showResults = q.trim().length > 0;

  return (
    <div className="noscroll" style={{ height: '100%', overflowY: 'auto', paddingBottom: 168 }}>
      <BigTitle title="Découverte" />
      <div style={{ padding: '0 16px 16px' }}>
        <SearchField value={q} onChange={setQ} placeholder="Artistes, titres, sons…" />
      </div>

      {!showResults ? (
        <div>
          {/* recents */}
          <div className="t-section" style={{ padding: '0 16px 10px' }}>Recherches récentes</div>
          <div className="noscroll" style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '0 16px 4px' }}>
            {discovery.recents.map((r) => <Chip key={r} onClick={() => setQ(r)}>{r}</Chip>)}
          </div>

          {/* trending */}
          <div style={{ marginTop: 26 }}>
            <SectionHeader action="Tout voir">Tendances</SectionHeader>
            <div className="noscroll" style={{ display: 'flex', gap: 14, overflowX: 'auto', padding: '0 16px 4px' }}>
              {discovery.trending.map((t, i) => <TrendCard key={t.id} track={t} rank={i + 1} onPlay={onPlay} />)}
            </div>
          </div>

          {/* artists */}
          <div style={{ marginTop: 26 }}>
            <SectionHeader>Artistes populaires</SectionHeader>
            <div className="noscroll" style={{ display: 'flex', gap: 18, overflowX: 'auto', padding: '0 16px 4px' }}>
              {discovery.artists.map((a) => <ArtistBubble key={a.name} a={a} onClick={() => setArtist(a)} />)}
            </div>
          </div>
        </div>
      ) : (
        <div>
          {Object.entries(discovery.results).map(([src, list], gi) => (
            <div key={src} style={{ marginBottom: 14 }}>
              <SectionHeader action="Tout voir">{src}</SectionHeader>
              {list.map((t, i) => (
                <div key={t.id} className="enter-rise" style={{ transitionDelay: `${(gi * 3 + i) * 0.05}s` }}>
                  <Cell track={t} onPlay={onPlay} onMenu={setMenu} sep={i < list.length - 1} />
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {menu && <OptionsSheet track={menu} onClose={() => setMenu(null)}
        onPlay={(t) => { setMenu(null); onPlay(t); }}
        onDownload={(fmt) => { setMenu(null); onDownload(menu, fmt); }} />}
    </div>
  );
}

window.DiscoveryScreen = DiscoveryScreen;
