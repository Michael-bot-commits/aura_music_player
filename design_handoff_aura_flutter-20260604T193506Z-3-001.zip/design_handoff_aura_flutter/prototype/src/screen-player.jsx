/* ============================================================
   screen-player.jsx — full-screen immersive player.
   blurred-artwork backdrop (crossfades on track change) + dark
   veil + dynamic wash · scaling cover · lyrics + queue tabs.
   Exports: PlayerScreen
   ============================================================ */

const LYRICS = [
  '(instrumental)', 'snow falls on the empty line', 'a signal lost in the white',
  'i hear you breaking up, distorted', 'static where your voice should be',
  'hold on — the carrier fades', 'every word a little softer now',
  'we drift between the frequencies', 'and the night keeps tuning out',
  'distorted, distorted', 'i keep you in the noise', 'where nothing else can reach',
  '(instrumental)', 'fading', 'fading', '—',
];

function PlayerScreen({ track, queue, index, playing, progress, liked, shuffle, repeat,
  volume, ctx, onToggle, onNext, onPrev, onSeek, onClose, onLike, onShuffle, onRepeat,
  onVolume, onJump }) {

  const [view, setView] = React.useState('cover');     // cover | lyrics | queue
  const [layers, setLayers] = React.useState([{ k: 0, art: track.art }]);
  const kref = React.useRef(0);

  // crossfade backdrop on track change
  React.useEffect(() => {
    kref.current += 1;
    setLayers((L) => [...L, { k: kref.current, art: track.art }]);
    const t = setTimeout(() => setLayers((L) => L.slice(-1)), 700);
    return () => clearTimeout(t);
  }, [track.art]);

  const elapsed = track.dur * progress;
  const lyricLine = Math.floor(progress * LYRICS.length);

  return (
    <div className="enter-sheet" style={{ position: 'absolute', inset: 0, zIndex: 60, color: 'var(--label)',
      overflow: 'hidden', background: '#000' }}>

      {/* ── crossfading blurred backdrop ── */}
      {layers.map((l) => (
        <div key={l.k} className="enter-cross" style={{ position: 'absolute', inset: -60 }}>
          <img src={window.ARTWORKS[l.art]} alt="" style={{ width: '100%', height: '100%',
            objectFit: 'cover', filter: 'blur(var(--pblur, 34px)) saturate(140%)', transform: 'scale(1.25)' }} />
        </div>
      ))}
      {/* dynamic wash + dark veil for contrast */}
      <div style={{ position: 'absolute', inset: 0, background: 'var(--dyn-soft)', opacity: 0.5,
        mixBlendMode: 'multiply', transition: 'background var(--dur-dyn) var(--ease)' }} />
      <div style={{ position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.2) 32%, rgba(0,0,0,0.55) 72%, rgba(0,0,0,0.86) 100%)' }} />

      {/* ── content column ── */}
      <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column',
        padding: '0 22px', paddingTop: 58 }}>

        {/* header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <IconBtn icon="chevronDown" onClick={onClose} glyph={20} />
          <div style={{ textAlign: 'center', lineHeight: 1.25 }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, color: 'rgba(255,255,255,0.82)' }}>{ctx}</div>
            <div style={{ fontSize: 10.5, color: 'rgba(255,255,255,0.5)', letterSpacing: 0.3 }}>en lecture</div>
          </div>
          <IconBtn icon="ellipsis" onClick={() => {}} glyph={20} />
        </div>

        {/* flexible region: cover / lyrics / queue */}
        <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column',
          justifyContent: 'center', padding: '14px 0' }}>
          {view === 'cover' && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ transform: playing ? 'scale(1)' : 'scale(0.82)',
                transition: 'transform .42s cubic-bezier(.32,.72,0,1)' }}>
                <Art id={track.art} size={300} radius={16} shadow />
              </div>
            </div>
          )}
          {view === 'lyrics' && (
            <div className="noscroll" style={{ overflowY: 'auto', maxHeight: '100%', padding: '20px 4px',
              maskImage: 'linear-gradient(transparent, #000 14%, #000 86%, transparent)',
              WebkitMaskImage: 'linear-gradient(transparent, #000 14%, #000 86%, transparent)' }}>
              {LYRICS.map((ln, i) => (
                <div key={i} style={{ fontSize: 22, fontWeight: 700, letterSpacing: -0.4, padding: '9px 0',
                  color: i === lyricLine ? '#fff' : i < lyricLine ? 'rgba(255,255,255,0.4)' : 'rgba(255,255,255,0.32)',
                  transform: i === lyricLine ? 'scale(1.02)' : 'none', transformOrigin: 'left',
                  transition: 'color .3s, transform .3s' }}>{ln}</div>
              ))}
            </div>
          )}
          {view === 'queue' && (
            <div className="noscroll" style={{ overflowY: 'auto', maxHeight: '100%' }}>
              <div className="t-section" style={{ marginBottom: 10 }}>À suivre</div>
              {queue.map((t, i) => i > index && (
                <div key={t.id} className="press" onClick={() => onJump(i)}
                  style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 0', cursor: 'pointer' }}>
                  <Art id={t.art} size={42} radius={7} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 15, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.title}</div>
                    <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.55)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.artist}</div>
                  </div>
                  <Icon name="queue" size={18} color="rgba(255,255,255,0.4)" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* title + heart */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 27, fontWeight: 700, letterSpacing: -0.5, whiteSpace: 'nowrap',
              overflow: 'hidden', textOverflow: 'ellipsis' }}>{track.title}</div>
            <div style={{ fontSize: 17, color: 'rgba(255,255,255,0.62)', whiteSpace: 'nowrap', overflow: 'hidden',
              textOverflow: 'ellipsis', marginTop: 2 }}>{track.artist}</div>
          </div>
          <IconBtn icon={liked ? 'heartFill' : 'heart'} bare onClick={onLike}
            color={liked ? 'var(--accent)' : '#fff'} glyph={26} style={{ marginTop: 2 }} />
        </div>

        {/* scrubber */}
        <div style={{ marginTop: 6 }}>
          <Scrubber value={progress} onChange={onSeek} />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: -2 }}>
            <span className="mono" style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{fmtTime(elapsed)}</span>
            <span className="mono" style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>-{fmtTime(track.dur - elapsed)}</span>
          </div>
        </div>

        {/* transport */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 4px 0' }}>
          <IconBtn icon="shuffle" bare glyph={20} active={shuffle} onClick={onShuffle} />
          <IconBtn icon="backward" bare glyph={30} onClick={onPrev} />
          <button className="press" onClick={() => { haptic('medium'); onToggle(); }}
            style={{ width: 70, height: 70, borderRadius: '50%', border: 'none', background: '#fff', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 6px 24px rgba(0,0,0,0.4)' }}>
            <Icon name={playing ? 'pause' : 'play'} size={32} color="#0a0a0b"
              style={{ marginLeft: playing ? 0 : 3 }} />
          </button>
          <IconBtn icon="forward" bare glyph={30} onClick={onNext} />
          <IconBtn icon="repeat" bare glyph={20} active={repeat} onClick={onRepeat} />
        </div>

        {/* volume */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '18px 2px 4px' }}>
          <Icon name="speakerLow" size={16} color="rgba(255,255,255,0.55)" />
          <div style={{ flex: 1 }}>
            <Scrubber value={volume} onChange={onVolume} track="rgba(255,255,255,0.18)" />
          </div>
          <Icon name="speakerHigh" size={18} color="rgba(255,255,255,0.55)" />
        </div>

        {/* secondary + tabs */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          paddingBottom: 26, marginTop: 2 }}>
          <PlayerTab label="Paroles" icon="quote" active={view === 'lyrics'}
            onClick={() => setView(view === 'lyrics' ? 'cover' : 'lyrics')} />
          <IconBtn icon="airplay" bare glyph={20} color="rgba(255,255,255,0.7)" onClick={() => {}} />
          <PlayerTab label="File d'attente" icon="queue" active={view === 'queue'}
            onClick={() => setView(view === 'queue' ? 'cover' : 'queue')} right />
        </div>
      </div>
    </div>
  );
}

function PlayerTab({ label, icon, active, onClick, right }) {
  return (
    <button className="press" onClick={() => { haptic('light'); onClick(); }}
      style={{ border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center',
        gap: 6, padding: '6px 2px', color: active ? 'var(--accent)' : 'rgba(255,255,255,0.7)',
        flexDirection: right ? 'row-reverse' : 'row' }}>
      <Icon name={icon} size={18} color="currentColor" />
      <span style={{ fontSize: 13, fontWeight: 600, position: 'relative' }}>
        {label}
        {active && <span style={{ position: 'absolute', left: 0, right: 0, bottom: -5, height: 2,
          borderRadius: 2, background: 'var(--accent)' }} />}
      </span>
    </button>
  );
}

window.PlayerScreen = PlayerScreen;
