/* ============================================================
   components.jsx — base components (states + haptic-ish press)
   Exports: PrimaryBtn, SecondaryBtn, IconBtn, Segmented, SearchField,
            Pill, Scrubber, Ring, Cell, SectionHeader, Toast, Handle
   ============================================================ */

// haptic stub — light/medium/success/error
function haptic(kind = 'light') {
  if (!navigator.vibrate) return;
  navigator.vibrate(kind === 'medium' ? 12 : kind === 'success' ? [8, 30, 8] : kind === 'error' ? [12, 40, 12] : 6);
}

// ---- buttons ----------------------------------------------------------
function PrimaryBtn({ icon, children, onClick, disabled, loading, full = true, style = {} }) {
  return (
    <button className="press" onClick={() => { if (!disabled && !loading) { haptic('medium'); onClick && onClick(); } }}
      disabled={disabled}
      style={{
        height: 52, width: full ? '100%' : 'auto', padding: '0 24px',
        borderRadius: 'var(--r-pill)', border: 'none',
        background: disabled ? 'var(--bg-3)' : 'var(--accent)',
        color: disabled ? 'var(--label-3)' : 'var(--accent-ink)',
        fontFamily: 'var(--font)', fontWeight: 600, fontSize: 17, letterSpacing: -0.2,
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        cursor: disabled ? 'default' : 'pointer', position: 'relative', overflow: 'hidden', ...style,
      }}>
      {loading
        ? <span className="shimmer" style={{ position: 'absolute', inset: 0, opacity: 0.4 }} />
        : <>{icon && <Icon name={icon} size={19} color="currentColor" />}{children}</>}
    </button>
  );
}

function SecondaryBtn({ icon, children, onClick, style = {}, full = false, tone = 'glass' }) {
  const glass = tone === 'glass';
  return (
    <button className="press" onClick={() => { haptic('light'); onClick && onClick(); }}
      style={{
        height: 52, width: full ? '100%' : 'auto', padding: '0 20px',
        borderRadius: 'var(--r-pill)',
        border: glass ? '1px solid var(--separator)' : 'none',
        background: glass ? 'var(--fill-3)' : 'var(--fill-1)',
        color: 'var(--label)', fontFamily: 'var(--font)', fontWeight: 600, fontSize: 16,
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
        cursor: 'pointer', ...style,
      }}>
      {icon && <Icon name={icon} size={18} color="currentColor" />}{children}
    </button>
  );
}

// glass circular icon button, 44pt hit target
function IconBtn({ icon, size = 44, glyph = 20, onClick, active, color, fill, bare = false, style = {} }) {
  return (
    <button className="press" onClick={() => { haptic('light'); onClick && onClick(); }}
      style={{
        width: size, height: size, borderRadius: '50%', border: 'none',
        background: bare ? 'transparent' : 'rgba(120,120,128,0.24)',
        backdropFilter: bare ? 'none' : 'blur(18px)', WebkitBackdropFilter: bare ? 'none' : 'blur(18px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        color: active ? 'var(--accent)' : (color || 'var(--label)'), flexShrink: 0, ...style,
      }}>
      <Icon name={fill || icon} size={glyph} color="currentColor" />
    </button>
  );
}

// ---- segmented control ------------------------------------------------
function Segmented({ items, value, onChange }) {
  const i = items.indexOf(value);
  return (
    <div style={{
      display: 'flex', position: 'relative', background: 'var(--fill-3)',
      borderRadius: 'var(--r-pill)', padding: 3, height: 36,
    }}>
      <div style={{
        position: 'absolute', top: 3, bottom: 3, left: `calc(${(i * 100) / items.length}% + 3px)`,
        width: `calc(${100 / items.length}% - 6px)`, background: 'var(--fill-1)',
        borderRadius: 'var(--r-pill)', transition: 'left var(--dur) var(--ease)',
        boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
      }} />
      {items.map((it) => (
        <button key={it} onClick={() => { haptic('light'); onChange(it); }}
          style={{
            flex: 1, zIndex: 1, border: 'none', background: 'transparent', cursor: 'pointer',
            fontFamily: 'var(--font)', fontWeight: it === value ? 600 : 500, fontSize: 14,
            color: it === value ? 'var(--label)' : 'var(--label-2)',
            transition: 'color var(--dur) ease',
          }}>{it}</button>
      ))}
    </div>
  );
}

// ---- search capsule ---------------------------------------------------
function SearchField({ value, onChange, placeholder = 'Rechercher', mic = true, onFocus, autoFocus }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8, height: 40, padding: '0 12px',
      background: 'var(--fill-3)', borderRadius: 'var(--r-pill)',
    }}>
      <Icon name="search" size={17} color="var(--label-2)" sw={2.2} />
      <input value={value} onChange={(e) => onChange && onChange(e.target.value)} placeholder={placeholder}
        onFocus={onFocus} autoFocus={autoFocus}
        style={{
          flex: 1, border: 'none', outline: 'none', background: 'transparent',
          color: 'var(--label)', fontFamily: 'var(--font)', fontSize: 16, minWidth: 0,
        }} />
      {mic && <Icon name="mic" size={17} color="var(--label-2)" sw={2.2} />}
    </div>
  );
}

// ---- pill / badge -----------------------------------------------------
function Pill({ children, tone = 'fill', color, style = {} }) {
  const bg = tone === 'accent' ? 'color-mix(in srgb, var(--accent) 18%, transparent)'
    : tone === 'ghost' ? 'transparent' : 'var(--fill-3)';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4, height: 22, padding: '0 9px',
      borderRadius: 'var(--r-pill)', background: bg,
      border: tone === 'ghost' ? '1px solid var(--separator)' : 'none',
      fontSize: 11.5, fontWeight: 600, letterSpacing: 0.2,
      color: color || (tone === 'accent' ? 'var(--accent)' : 'var(--label-2)'), ...style,
    }}>{children}</span>
  );
}

// ---- scrubber (audio progress, 4px track, 11px thumb) ----------------
function Scrubber({ value, onChange, accent = 'var(--accent)', track = 'rgba(255,255,255,0.2)' }) {
  const ref = React.useRef(null);
  const [drag, setDrag] = React.useState(false);
  const set = (clientX) => {
    const r = ref.current.getBoundingClientRect();
    const v = Math.min(1, Math.max(0, (clientX - r.left) / r.width));
    onChange && onChange(v);
  };
  const down = (e) => { setDrag(true); haptic('light'); set(e.clientX ?? e.touches[0].clientX); };
  React.useEffect(() => {
    if (!drag) return;
    const mv = (e) => set(e.clientX ?? (e.touches && e.touches[0].clientX));
    const up = () => setDrag(false);
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    return () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); };
  });
  return (
    <div ref={ref} onPointerDown={down} style={{ padding: '10px 0', cursor: 'pointer', touchAction: 'none' }}>
      <div style={{ height: 4, borderRadius: 2, background: track, position: 'relative' }}>
        <div style={{ position: 'absolute', inset: 0, width: `${value * 100}%`, background: accent, borderRadius: 2 }} />
        <div style={{
          position: 'absolute', top: '50%', left: `${value * 100}%`,
          width: drag ? 15 : 11, height: drag ? 15 : 11, borderRadius: '50%', background: '#fff',
          transform: 'translate(-50%,-50%)', boxShadow: '0 1px 4px rgba(0,0,0,0.4)',
          transition: 'width .12s, height .12s',
        }} />
      </div>
    </div>
  );
}

// ---- progress ring (downloads) ---------------------------------------
function Ring({ progress = 0, size = 34, sw = 3, state = 'downloading' }) {
  const r = (size - sw) / 2, c = 2 * Math.PI * r;
  if (state === 'done') return <Icon name="checkCircle" size={size * 0.82} color="var(--success)" />;
  if (state === 'error') return <Icon name="errorCircle" size={size * 0.82} color="var(--accent)" />;
  if (state === 'queued') {
    return (
      <div style={{ width: size, height: size, borderRadius: '50%', border: `${sw}px solid var(--separator)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name="clock" size={size * 0.5} color="var(--label-3)" sw={2.2} />
      </div>
    );
  }
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--fill-2)" strokeWidth={sw} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--accent)" strokeWidth={sw}
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - progress)}
          style={{ transition: 'stroke-dashoffset .4s ease' }} />
      </svg>
      <span style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 9.5, fontWeight: 600, color: 'var(--label-2)',
      }}>{Math.round(progress * 100)}</span>
    </div>
  );
}

// ---- list cell (64pt) -------------------------------------------------
function Cell({ track, onPlay, onMenu, trailing, sep = true, artSize = 52, playing = false }) {
  return (
    <div className="press" onClick={() => onPlay && onPlay(track)}
      style={{ display: 'flex', alignItems: 'center', gap: 12, height: 64, padding: '0 16px',
        position: 'relative', cursor: 'pointer' }}>
      <Art id={track.art} size={artSize} radius={8} badge={track.kind === 'video'} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 16, fontWeight: 600, color: playing ? 'var(--accent)' : 'var(--label)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', letterSpacing: -0.2 }}>{track.title}</div>
        <div style={{ fontSize: 14, color: 'var(--label-2)', whiteSpace: 'nowrap', overflow: 'hidden',
          textOverflow: 'ellipsis', marginTop: 2 }}>{track.artist}</div>
      </div>
      {trailing !== undefined ? trailing : (
        <>
          <span className="mono" style={{ fontSize: 13, color: 'var(--label-3)' }}>{fmtTime(track.dur)}</span>
          <button className="press" onClick={(e) => { e.stopPropagation(); haptic('light'); onMenu && onMenu(track); }}
            style={{ border: 'none', background: 'transparent', cursor: 'pointer', padding: 6, color: 'var(--label-2)' }}>
            <Icon name="ellipsis" size={18} />
          </button>
        </>
      )}
      {sep && <div style={{ position: 'absolute', left: artSize + 28, right: 0, bottom: 0, height: 0.5, background: 'var(--separator)' }} />}
    </div>
  );
}

function SectionHeader({ children, action, onAction, style = {} }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
      padding: '0 16px 10px', ...style }}>
      <span className="t-section">{children}</span>
      {action && <button onClick={onAction} style={{ border: 'none', background: 'none', cursor: 'pointer',
        color: 'var(--accent)', fontSize: 14, fontWeight: 600, fontFamily: 'var(--font)',
        display: 'flex', alignItems: 'center', gap: 2 }}>{action}<Icon name="chevronRight" size={13} /></button>}
    </div>
  );
}

// ---- toast ------------------------------------------------------------
function Toast({ icon, children, tone = 'default' }) {
  const col = tone === 'success' ? 'var(--success)' : tone === 'error' ? 'var(--accent)' : 'var(--label)';
  return (
    <div className="glass enter-rise" style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '12px 18px', borderRadius: 'var(--r-pill)',
      boxShadow: '0 8px 30px rgba(0,0,0,0.5)', border: '0.5px solid var(--separator-op)',
    }}>
      {icon && <Icon name={icon} size={18} color={col} />}
      <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--label)' }}>{children}</span>
    </div>
  );
}

// drag handle for sheets
function Handle() {
  return <div style={{ width: 36, height: 5, borderRadius: 3, background: 'var(--label-3)', margin: '8px auto' }} />;
}

Object.assign(window, { haptic, PrimaryBtn, SecondaryBtn, IconBtn, Segmented, SearchField, Pill, Scrubber, Ring, Cell, SectionHeader, Toast, Handle });
