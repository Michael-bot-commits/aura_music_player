/* ============================================================
   app.jsx — AURA media player shell.
   device frame + scaling stage + global state (playback, dynamic
   colour, nav) + interception/menu sheets + toasts + Tweaks.
   ============================================================ */

const ACCENTS = {
  coral:  { c: '#FF6E72', name: 'Corail' },
  blue:   { c: '#3B86FF', name: 'Bleu' },
  green:  { c: '#32D74B', name: 'Vert' },
  violet: { c: '#C77DFF', name: 'Violet' },
};

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#FF6E72",
  "pblur": 34,
  "dynamic": true,
  "miniProgress": true
}/*EDITMODE-END*/;

// ── generic context menu (library cell ···) ──
function ContextMenuSheet({ track, onClose, onAction }) {
  const rows = [
    { icon: 'queue', label: 'Lire ensuite' },
    { icon: 'plus', label: 'Ajouter à une playlist' },
    { icon: 'download', label: 'Télécharger' },
    { icon: 'share', label: 'Partager' },
  ];
  return (
    <div className="enter-fade" style={{ position: 'absolute', inset: 0, zIndex: 70, display: 'flex', flexDirection: 'column',
      justifyContent: 'flex-end' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.4)' }} />
      <div className="enter-sheet" style={{ position: 'relative', background: 'var(--bg-2)', borderRadius: '22px 22px 0 0',
        padding: '0 0 28px' }}>
        <Handle />
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 18px 14px' }}>
          <Art id={track.art} size={46} radius={9} />
          <div><div style={{ fontSize: 16, fontWeight: 600 }}>{track.title}</div>
            <div style={{ fontSize: 13, color: 'var(--label-2)' }}>{track.artist}</div></div>
        </div>
        {rows.map((r, i) => (
          <button key={i} className="press" onClick={() => onAction(r.label)} style={{ width: '100%', border: 'none',
            background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 20px', color: 'var(--label)', fontFamily: 'var(--font)', fontSize: 16,
            borderTop: '0.5px solid var(--separator)' }}>
            <Icon name={r.icon} size={20} color="var(--accent)" />{r.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const { queue } = window.DATA;

  const [tab, setTab] = React.useState('library');
  const [libView, setLibView] = React.useState('library');
  const [playerOpen, setPlayerOpen] = React.useState(false);
  const [index, setIndex] = React.useState(0);
  const [playing, setPlaying] = React.useState(true);
  const [progress, setProgress] = React.useState(0.29);
  const [liked, setLiked] = React.useState(() => new Set(['goldhour']));
  const [shuffle, setShuffle] = React.useState(false);
  const [repeat, setRepeat] = React.useState(false);
  const [volume, setVolume] = React.useState(0.62);
  const [tint, setTint] = React.useState({ dom: '#3a3a40', soft: '#1a1a1e', glow: 'rgba(120,120,140,0.4)' });
  const [intercept, setIntercept] = React.useState(null);
  const [menu, setMenu] = React.useState(null);
  const [toast, setToast] = React.useState(null);

  const track = queue[index];
  const rootRef = React.useRef(null);

  // ── playback ticker ──
  React.useEffect(() => {
    if (!playing) return;
    const iv = setInterval(() => {
      setProgress((p) => {
        const np = p + 1 / track.dur;
        if (np >= 1) { setIndex((i) => (i + 1) % queue.length); return 0; }
        return np;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [playing, track.dur, queue.length]);

  // ── dynamic colour extraction on track change ──
  React.useEffect(() => {
    if (!t.dynamic) {
      setTint({ dom: '#3a3a40', soft: '#16161a', glow: 'rgba(120,120,140,0.35)' });
      return;
    }
    let alive = true;
    window.AuraColor.fromSrc(window.ARTWORKS[track.art]).then((c) => { if (alive) setTint(c); });
    return () => { alive = false; };
  }, [track.art, t.dynamic]);

  // ── push tint + accent + blur to CSS vars ──
  React.useEffect(() => {
    const r = rootRef.current; if (!r) return;
    r.style.setProperty('--dyn', tint.dom);
    r.style.setProperty('--dyn-soft', tint.soft);
    r.style.setProperty('--dyn-glow', tint.glow);
    r.style.setProperty('--accent', t.accent);
    r.style.setProperty('--pblur', t.pblur + 'px');
  }, [tint, t.accent, t.pblur]);

  // ── stage scaling ──
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const fit = () => {
      const s = Math.min((window.innerWidth - 24) / 402, (window.innerHeight - 24) / 874, 1);
      setScale(s);
    };
    fit(); window.addEventListener('resize', fit); return () => window.removeEventListener('resize', fit);
  }, []);

  // ── actions ──
  const flash = (msg, tone, icon) => { setToast({ msg, tone, icon }); clearTimeout(flash._t);
    flash._t = setTimeout(() => setToast(null), 2200); };
  const playTrack = (tr) => { const i = queue.findIndex((q) => q.id === tr.id);
    if (i >= 0) { setIndex(i); setProgress(0); setPlaying(true); setPlayerOpen(true); } };
  const next = () => { setIndex((i) => (i + 1) % queue.length); setProgress(0); };
  const prev = () => { if (progress > 0.04) { setProgress(0); } else { setIndex((i) => (i - 1 + queue.length) % queue.length); setProgress(0); } };
  const toggleLike = () => setLiked((L) => { const n = new Set(L); n.has(track.id) ? n.delete(track.id) : n.add(track.id); return n; });

  const onTab = (id) => {
    if (id === 'player') { setPlayerOpen(true); return; }
    setPlayerOpen(false); setTab(id); if (id === 'library') setLibView('library');
  };

  const dlActive = window.DATA.downloads.active.filter((d) => d.state === 'downloading' || d.state === 'queued').length;

  // ── current screen ──
  let screen;
  if (tab === 'browser') screen = <BrowserScreen onDetect={(tr, src) => setIntercept({ track: tr, source: src })} />;
  else if (tab === 'discovery') screen = <DiscoveryScreen onPlay={playTrack}
    onDownload={(tr, fmt) => flash(`Téléchargement ${fmt} lancé`, 'default', 'download')} />;
  else screen = libView === 'downloads'
    ? <DownloadsScreen onBack={() => setLibView('library')} />
    : <LibraryScreen playingId={track.id} onPlay={playTrack} onMenu={setMenu}
        onDownloads={() => setLibView('downloads')} dlActive={dlActive} />;

  return (
    <div ref={rootRef} className="app" style={{ width: '100vw', height: '100vh', display: 'flex',
      alignItems: 'center', justifyContent: 'center', overflow: 'hidden', background: '#0a0a0b' }}>
      <div style={{ transform: `scale(${scale})`, transformOrigin: 'center' }}>
        {/* device frame */}
        <div style={{ width: 402, height: 874, borderRadius: 52, background: 'var(--bg)', position: 'relative',
          overflow: 'hidden', boxShadow: '0 50px 100px rgba(0,0,0,0.6), 0 0 0 11px #1a1a1c, 0 0 0 12px #2c2c2e' }}>

          {/* dynamic island */}
          <div style={{ position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
            width: 124, height: 36, borderRadius: 22, background: '#000', zIndex: 90 }} />
          {/* status bar */}
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 85, pointerEvents: 'none' }}>
            <IOSStatusBar dark />
          </div>

          {/* screen content */}
          <div style={{ position: 'absolute', inset: 0, paddingTop: 50 }}>
            <div style={{ height: '100%' }}>{screen}</div>
          </div>

          {/* fused chrome — hidden on downloads sub-view for focus */}
          {!playerOpen && (
            <Chrome tab={tab} onTab={onTab} track={track} playing={playing} progress={progress}
              onToggle={() => setPlaying((p) => !p)} onNext={next} onPrev={prev}
              onOpen={() => setPlayerOpen(true)} dlActive={dlActive} miniProgress={t.miniProgress} />
          )}

          {/* full-screen player */}
          {playerOpen && (
            <PlayerScreen track={track} queue={queue} index={index} playing={playing} progress={progress}
              liked={liked.has(track.id)} shuffle={shuffle} repeat={repeat} volume={volume}
              ctx={tab === 'discovery' ? 'DÉCOUVERTE · MIX' : 'BIBLIOTHÈQUE · NUITS FEUTRÉES'}
              onToggle={() => setPlaying((p) => !p)} onNext={next} onPrev={prev} onSeek={setProgress}
              onClose={() => setPlayerOpen(false)} onLike={toggleLike}
              onShuffle={() => { setShuffle((s) => !s); haptic('light'); }}
              onRepeat={() => { setRepeat((r) => !r); haptic('light'); }}
              onVolume={setVolume} onJump={(i) => { setIndex(i); setProgress(0); }} />
          )}

          {/* interception sheet */}
          {intercept && (
            <InterceptSheet track={intercept.track} source={intercept.source}
              onClose={() => setIntercept(null)}
              onPlay={() => { playTrack(intercept.track); setIntercept(null); }}
              onDownload={(fmt) => { setIntercept(null); flash(`Téléchargement ${fmt} lancé`, 'default', 'download'); }}
              onShare={() => { setIntercept(null); flash('Lien copié', 'success', 'check'); }} />
          )}

          {/* context menu */}
          {menu && <ContextMenuSheet track={menu} onClose={() => setMenu(null)}
            onAction={(label) => { setMenu(null);
              flash(label === 'Télécharger' ? 'Téléchargement lancé' : label, 'default',
                label === 'Télécharger' ? 'download' : label === 'Partager' ? 'share' : 'check'); }} />}

          {/* toast */}
          {toast && (
            <div style={{ position: 'absolute', left: 0, right: 0, bottom: playerOpen ? 40 : 160, zIndex: 80,
              display: 'flex', justifyContent: 'center', pointerEvents: 'none' }}>
              <Toast icon={toast.icon} tone={toast.tone}>{toast.msg}</Toast>
            </div>
          )}
        </div>
      </div>

      {/* Tweaks */}
      <TweaksPanel>
        <TweakSection label="Identité" />
        <TweakColor label="Accent" value={t.accent}
          options={[ACCENTS.coral.c, ACCENTS.blue.c, ACCENTS.green.c, ACCENTS.violet.c]}
          onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Player" />
        <TweakSlider label="Flou de pochette" value={t.pblur} min={10} max={60} unit="px"
          onChange={(v) => setTweak('pblur', v)} />
        <TweakToggle label="Couleur dynamique" value={t.dynamic} onChange={(v) => setTweak('dynamic', v)} />
        <TweakToggle label="Progression mini-player" value={t.miniProgress} onChange={(v) => setTweak('miniProgress', v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
