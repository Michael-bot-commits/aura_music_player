/* ============================================================
   artwork.js — generates abstract album covers as raster PNGs.
   Drawn on a local canvas → data URL → never taints the sampling
   canvas. Each cover commits to one dominant hue so the player's
   live colour extraction produces a clear, distinct tint.
   Builds window.ARTWORKS  { id: dataUrl }
   ============================================================ */
(function () {
  const S = 640;

  function mix(a, b, t) {
    const ah = parseInt(a.slice(1), 16), bh = parseInt(b.slice(1), 16);
    const ar = ah >> 16, ag = (ah >> 8) & 255, ab = ah & 255;
    const br = bh >> 16, bg = (bh >> 8) & 255, bb = bh & 255;
    const r = Math.round(ar + (br - ar) * t);
    const g = Math.round(ag + (bg - ag) * t);
    const bl = Math.round(ab + (bb - ab) * t);
    return `rgb(${r},${g},${bl})`;
  }

  // deterministic pseudo-random
  function rng(seed) {
    let s = seed % 2147483647; if (s <= 0) s += 2147483646;
    return () => (s = (s * 16807) % 2147483647) / 2147483647;
  }

  // ---- cover styles ----------------------------------------------------
  function meshGradient(ctx, pal, rand) {
    // base fill
    ctx.fillStyle = pal.base; ctx.fillRect(0, 0, S, S);
    // soft radial blobs of the dominant + accents
    const blobs = 5;
    for (let i = 0; i < blobs; i++) {
      const x = rand() * S, y = rand() * S, r = S * (0.35 + rand() * 0.45);
      const col = [pal.dom, pal.dom, pal.accent, pal.deep][i % 4];
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, col);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.globalAlpha = 0.55 + rand() * 0.3;
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function bandsStyle(ctx, pal, rand) {
    ctx.fillStyle = pal.base; ctx.fillRect(0, 0, S, S);
    const g = ctx.createLinearGradient(0, 0, S, S);
    g.addColorStop(0, pal.deep); g.addColorStop(0.5, pal.dom); g.addColorStop(1, pal.accent);
    ctx.fillStyle = g; ctx.fillRect(0, 0, S, S);
    // diagonal sheen
    ctx.globalAlpha = 0.12;
    for (let i = -2; i < 10; i++) {
      ctx.fillStyle = i % 2 ? '#ffffff' : '#000000';
      ctx.save(); ctx.translate(S / 2, S / 2); ctx.rotate(-0.5);
      ctx.fillRect(-S + i * 90, -S, 46, S * 2); ctx.restore();
    }
    ctx.globalAlpha = 1;
  }

  function orbStyle(ctx, pal, rand) {
    ctx.fillStyle = pal.base; ctx.fillRect(0, 0, S, S);
    const cx = S * (0.4 + rand() * 0.2), cy = S * (0.42 + rand() * 0.2);
    const halo = ctx.createRadialGradient(cx, cy, 0, cx, cy, S * 0.7);
    halo.addColorStop(0, pal.dom); halo.addColorStop(0.55, pal.deep);
    halo.addColorStop(1, pal.base);
    ctx.fillStyle = halo; ctx.fillRect(0, 0, S, S);
    // crisp orb
    const orb = ctx.createRadialGradient(cx - 60, cy - 60, 20, cx, cy, S * 0.34);
    orb.addColorStop(0, pal.accent); orb.addColorStop(1, pal.dom);
    ctx.fillStyle = orb;
    ctx.beginPath(); ctx.arc(cx, cy, S * 0.30, 0, Math.PI * 2); ctx.fill();
  }

  function strataStyle(ctx, pal, rand) {
    const cols = [pal.deep, pal.dom, pal.accent, mix(pal.dom, '#ffffff', 0.25)];
    let y = 0;
    while (y < S) {
      const h = S * (0.08 + rand() * 0.16);
      ctx.fillStyle = cols[Math.floor(rand() * cols.length)];
      ctx.fillRect(0, y, S, h + 2);
      y += h;
    }
    // vignette
    const v = ctx.createRadialGradient(S/2, S/2, S*0.2, S/2, S/2, S*0.75);
    v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.45)');
    ctx.fillStyle = v; ctx.fillRect(0,0,S,S);
  }

  function grain(ctx) {
    const id = ctx.getImageData(0, 0, S, S), d = id.data;
    for (let i = 0; i < d.length; i += 4) {
      const n = (Math.random() - 0.5) * 14;
      d[i] += n; d[i+1] += n; d[i+2] += n;
    }
    ctx.putImageData(id, 0, 0);
  }

  const styles = [meshGradient, bandsStyle, orbStyle, strataStyle];

  // ---- palettes — each commits to one dominant hue --------------------
  const palettes = {
    distorted:   { base:'#1a0e12', deep:'#7a1f2b', dom:'#e0394b', accent:'#ff7a64' },
    nightswim:   { base:'#07131c', deep:'#0d3b54', dom:'#1f8fb8', accent:'#5fe0d6' },
    goldhour:    { base:'#1c1407', deep:'#8a5a12', dom:'#e0972a', accent:'#ffd36a' },
    violetstatic:{ base:'#15091c', deep:'#4a1d7a', dom:'#9b46e0', accent:'#d98cff' },
    fernyard:    { base:'#0a1410', deep:'#1d5a32', dom:'#34b35a', accent:'#9ff0a8' },
    coralcoast:  { base:'#1c0d0c', deep:'#a23a2e', dom:'#ff5a4d', accent:'#ffae8c' },
    slatebloom:  { base:'#101216', deep:'#384156', dom:'#6b7894', accent:'#aeb9d6' },
    magenta:     { base:'#1a0814', deep:'#7a1456', dom:'#e0349a', accent:'#ff86c8' },
    amberdusk:   { base:'#1a0f08', deep:'#9a4d18', dom:'#f08a3c', accent:'#ffc28a' },
    indigowave:  { base:'#0b0d1e', deep:'#262d72', dom:'#4a5ae0', accent:'#8ea0ff' },
    rosequartz:  { base:'#1c0f14', deep:'#9c3b58', dom:'#e8628a', accent:'#ffb0c6' },
    tealglass:   { base:'#06151a', deep:'#0f5560', dom:'#23a3b0', accent:'#6fe6e0' },
  };

  const ARTWORKS = {};
  let i = 0;
  for (const [id, pal] of Object.entries(palettes)) {
    const c = document.createElement('canvas'); c.width = S; c.height = S;
    const ctx = c.getContext('2d');
    const rand = rng(1000 + i * 137);
    styles[i % styles.length](ctx, pal, rand);
    grain(ctx);
    ARTWORKS[id] = c.toDataURL('image/png');
    i++;
  }

  window.ARTWORKS = ARTWORKS;
  // expose declared dominants too (fallback / seed)
  window.ART_DOMINANTS = Object.fromEntries(
    Object.entries(palettes).map(([k, v]) => [k, v.dom])
  );
})();
