/* ============================================================
   screen-browser.jsx — in-app browser + media detection.
   custom nav bar · shortcut grid · faux page · triggers the
   interception sheet (owned by App so it overlays the chrome).
   Exports: BrowserScreen, InterceptSheet
   ============================================================ */

function NavField({ url }) {
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      height: 38, padding: '0 14px', background: 'var(--fill-3)', borderRadius: 'var(--r-pill)' }}>
      <Icon name="lock" size={12} color="var(--label-2)" sw={2.2} />
      <span style={{ fontSize: 14, color: 'var(--label)', whiteSpace: 'nowrap', overflow: 'hidden',
        textOverflow: 'ellipsis', maxWidth: 180 }}>{url}</span>
    </div>
  );
}

function NavBtn({ icon, onClick, disabled, color }) {
  return (
    <button className="press" onClick={() => !disabled && onClick && onClick()} disabled={disabled}
      style={{ width: 34, height: 38, border: 'none', background: 'transparent',
        cursor: disabled ? 'default' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: disabled ? 'var(--label-4)' : (color || 'var(--label)') }}>
      <Icon name={icon} size={20} color="currentColor" sw={2} />
    </button>
  );
}

function ShortcutTile({ s, onClick }) {
  return (
    <button className="press" onClick={() => { haptic('light'); onClick(s); }}
      style={{ border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex',
        flexDirection: 'column', alignItems: 'center', gap: 8, padding: 0 }}>
      <div style={{ width: '100%', aspectRatio: '1', borderRadius: 14, background: 'var(--bg-3)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: s.hue, opacity: 0.16 }} />
        <span style={{ position: 'relative', fontSize: 22, fontWeight: 700, color: s.hue, letterSpacing: -0.5 }}>{s.name[0]}</span>
      </div>
      <span style={{ fontSize: 12, color: 'var(--label-2)', fontWeight: 500 }}>{s.name}</span>
    </button>
  );
}

function BrowserScreen({ onDetect }) {
  const { shortcuts, tracks } = window.DATA;
  const [url, setUrl] = React.useState('aura://accueil');
  const [loading, setLoading] = React.useState(false);
  const [page, setPage] = React.useState(null);   // { source, track }

  const openSource = (s) => {
    setUrl(s.host + '/watch');
    setLoading(true);
    setPage(null);
    setTimeout(() => {
      setLoading(false);
      const t = tracks.distorted;
      setPage({ source: s.name, track: t });
      setTimeout(() => { haptic('medium'); onDetect(t, s.name); }, 750);
    }, 850);
  };

  return (
    <div className="noscroll" style={{ height: '100%', overflowY: 'auto', paddingBottom: 168 }}>
      {/* custom nav bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '4px 12px 10px' }}>
        <NavBtn icon="arrowLeft" onClick={() => { setPage(null); setUrl('aura://accueil'); }} />
        <NavBtn icon="arrowRight" disabled />
        <NavField url={url} />
        <NavBtn icon="refresh" onClick={() => {}} />
        <NavBtn icon="homeFill" color="var(--accent)" onClick={() => { setPage(null); setUrl('aura://accueil'); }} />
      </div>

      {/* loading bar */}
      {loading && <div style={{ height: 2, margin: '0 16px', borderRadius: 2, overflow: 'hidden', background: 'var(--fill-2)' }}>
        <div className="shimmer" style={{ height: '100%', width: '60%' }} /></div>}

      {!page ? (
        <div style={{ padding: '6px 16px' }}>
          <div className="t-section" style={{ marginBottom: 12 }}>Raccourcis</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12 }}>
            {shortcuts.map((s) => <ShortcutTile key={s.name} s={s} onClick={openSource} />)}
          </div>

          <div className="t-section" style={{ margin: '28px 0 12px' }}>Récemment visités</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {['youtube.com/watch?v=…  ·  distorted', 'soundcloud.com/vela  ·  Coral Coast', 'vimeo.com/nightswim'].map((r, i) => (
              <div key={i} className="press" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0',
                cursor: 'pointer', borderBottom: '0.5px solid var(--separator)' }}>
                <div style={{ width: 34, height: 34, borderRadius: 8, background: 'var(--fill-3)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name="globe" size={17} color="var(--label-2)" /></div>
                <span style={{ fontSize: 14, color: 'var(--label-2)', whiteSpace: 'nowrap', overflow: 'hidden',
                  textOverflow: 'ellipsis' }}>{r}</span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        // faux watch page
        <div style={{ padding: '6px 16px' }}>
          <div style={{ position: 'relative', borderRadius: 14, overflow: 'hidden', aspectRatio: '16/10' }}>
            <img src={window.ARTWORKS[page.track.art]} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', filter: 'brightness(0.7)' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="playCircle" size={56} color="rgba(255,255,255,0.92)" />
            </div>
            <div style={{ position: 'absolute', left: 10, bottom: 10 }}>
              <Pill tone="ghost" style={{ background: 'rgba(0,0,0,0.5)', color: '#fff', borderColor: 'transparent', whiteSpace: 'nowrap' }}>vidéo détectée</Pill>
            </div>
          </div>
          <div style={{ fontSize: 17, fontWeight: 600, marginTop: 14, color: 'var(--label)' }}>{page.track.title} — {page.track.artist}</div>
          <div style={{ fontSize: 13, color: 'var(--label-2)', marginTop: 4 }}>{page.source} · 4:32 · 48 M vues</div>
          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[1, 0.8, 0.9, 0.6].map((w, i) => <div key={i} style={{ height: 11, borderRadius: 6, background: 'var(--fill-3)', width: `${w * 100}%` }} />)}
          </div>
        </div>
      )}
    </div>
  );
}

// ── interception bottom sheet (rendered by App, overlays chrome) ──
function InterceptSheet({ track, source, onPlay, onClose, onDownload, onShare }) {
  return (
    <div className="enter-fade" style={{ position: 'absolute', inset: 0, zIndex: 70, display: 'flex', flexDirection: 'column',
      justifyContent: 'flex-end' }}>
      <div onClick={onClose} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.4)' }} />
      <div className="enter-sheet" style={{ position: 'relative', background: 'var(--bg-2)', borderRadius: '22px 22px 0 0',
        padding: '0 18px calc(20px + env(safe-area-inset-bottom))', paddingBottom: 28,
        boxShadow: '0 -10px 40px rgba(0,0,0,0.5)' }}>
        <Handle />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
          <div style={{ fontSize: 12, fontWeight: 700, letterSpacing: 0.6, color: 'var(--accent)' }}>DÉTECTÉ · {source.toUpperCase()}</div>
          <IconBtn icon="x" bare glyph={18} color="var(--label-2)" onClick={onClose} size={32} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '8px 0 18px' }}>
          <Art id={track.art} size={56} radius={10} shadow />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 18, fontWeight: 700, letterSpacing: -0.3, color: 'var(--label)' }}>{track.title}</div>
            <div style={{ fontSize: 14, color: 'var(--label-2)' }}>{track.artist}</div>
          </div>
        </div>
        <PrimaryBtn icon="play" onClick={onPlay}>Lire maintenant</PrimaryBtn>
        <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
          <SecondaryBtn icon="download" full onClick={() => onDownload('audio')} style={{ flex: 1 }}>Audio</SecondaryBtn>
          <SecondaryBtn icon="download" full onClick={() => onDownload('vidéo')} style={{ flex: 1 }}>Vidéo</SecondaryBtn>
        </div>
        <button className="press" onClick={onShare} style={{ width: '100%', marginTop: 14, border: 'none',
          background: 'transparent', cursor: 'pointer', color: 'var(--label-2)', fontSize: 14, fontWeight: 600,
          fontFamily: 'var(--font)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7 }}>
          <Icon name="share" size={16} />Partager le lien
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { BrowserScreen, InterceptSheet });
