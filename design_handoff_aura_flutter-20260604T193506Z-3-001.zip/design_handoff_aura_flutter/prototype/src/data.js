/* ============================================================
   data.js — content model for the AURA media player.
   window.DATA = { tracks, queue, library, playlists, downloads,
                   discovery, shortcuts }
   ============================================================ */
(function () {
  // id maps 1:1 to window.ARTWORKS keys
  const T = (id, title, artist, album, dur, kind = 'audio', extra = {}) =>
    ({ id, title, artist, album, dur, kind, art: id, ...extra });

  const tracks = {
    distorted:    T('distorted',    'Distorted',     'øneheart, reidenshi', 'snowfall',        198),
    nightswim:    T('nightswim',    'Nightswim',     'Lytham',              'Tidal',           242, 'video'),
    goldhour:     T('goldhour',     'Gold Hour',     'Halna',               'Low Sun',         215),
    violetstatic: T('violetstatic', 'Violet Static', 'Mooncircuit',         'Noise Bloom',     187),
    fernyard:     T('fernyard',     'Fernyard',      'Cobalt Hours',        'Greenhouse',      263, 'video'),
    coralcoast:   T('coralcoast',   'Coral Coast',   'Vela',                'Saltwater',       201),
    slatebloom:   T('slatebloom',   'Slate Bloom',   'Aris Pell',           'Quiet Concrete',  229),
    magenta:      T('magenta',      'Magenta',       'NEØN',                'After Image',     176),
    amberdusk:    T('amberdusk',    'Amber Dusk',    'Hollow Pines',        'Long Light',      248),
    indigowave:   T('indigowave',   'Indigo Wave',   'Tessellate',          'Deep Field',      221, 'video'),
    rosequartz:   T('rosequartz',   'Rose Quartz',   'Lune',                'Soft Geometry',   194),
    tealglass:    T('tealglass',    'Teal Glass',    'Marin',               'Atoll',           233),
  };

  const order = ['distorted','nightswim','goldhour','violetstatic','coralcoast',
                 'magenta','amberdusk','indigowave','fernyard','slatebloom',
                 'rosequartz','tealglass'];

  const queue = order.map(id => tracks[id]);

  // — library (mix of music + video) —
  const library = order.map(id => tracks[id]);

  // — playlists (mosaic = 4 cover ids) —
  const playlists = [
    { id:'pl1', name:'Nuits feutrées',  arts:['distorted','violetstatic','magenta','indigowave'], count:24, dur:'1 h 18' },
    { id:'pl2', name:'Focus / lo-fi',   arts:['slatebloom','goldhour','tealglass','amberdusk'],    count:18, dur:'58 min' },
    { id:'pl3', name:'Pluie & verre',   arts:['nightswim','tealglass','indigowave','rosequartz'],  count:31, dur:'1 h 52' },
    { id:'pl4', name:'Rouge sombre',    arts:['coralcoast','distorted','magenta','amberdusk'],     count:12, dur:'41 min' },
  ];

  // — downloads —
  const downloads = {
    active: [
      { ...tracks.indigowave, state:'downloading', progress:0.68, fmt:'audio · m4a' },
      { ...tracks.fernyard,   state:'downloading', progress:0.34, fmt:'vidéo · 1080p' },
      { ...tracks.amberdusk,  state:'queued',      progress:0,    fmt:'en attente' },
      { ...tracks.magenta,    state:'error',       progress:0.12, fmt:'échec' },
    ],
    done: [
      { ...tracks.distorted,  state:'done', fmt:'audio · m4a · 4.8 Mo' },
      { ...tracks.goldhour,   state:'done', fmt:'audio · m4a · 5.1 Mo' },
      { ...tracks.coralcoast, state:'done', fmt:'audio · m4a · 4.6 Mo' },
      { ...tracks.tealglass,  state:'done', fmt:'vidéo · 720p · 38 Mo' },
    ],
  };

  // — discovery —
  const discovery = {
    recents: ['øneheart', 'lo-fi pluie', 'Vela', 'phonk doux', 'Mooncircuit'],
    trending: ['distorted','tealglass','magenta','goldhour','indigowave','coralcoast'].map(id => tracks[id]),
    artists: [
      { name:'øneheart',    art:'distorted',  listeners:'2,4 M' },
      { name:'Lune',        art:'rosequartz', listeners:'880 k' },
      { name:'Marin',       art:'tealglass',  listeners:'1,1 M' },
      { name:'NEØN',        art:'magenta',    listeners:'640 k' },
      { name:'Halna',       art:'goldhour',   listeners:'430 k' },
    ],
    results: {
      Deezer: ['distorted','coralcoast','amberdusk'].map(id => tracks[id]),
      SoundCloud: ['violetstatic','magenta','nightswim'].map(id => tracks[id]),
      Jamendo: ['slatebloom','goldhour'].map(id => tracks[id]),
    },
    artistPage: {
      name: 'øneheart',
      art: 'distorted',
      monthly: '2 412 880 auditeurs / mois',
      bio: "Producteur ambient et phonk atmosphérique, øneheart compose des paysages sonores feutrés où la basse se dissout dans le grain. Son morceau « distorted », né d'une collaboration avec reidenshi, est devenu l'hymne discret d'une génération nocturne — des millions d'écoutes, presque aucun mot.",
      discography: ['distorted','magenta','violetstatic','indigowave','amberdusk','slatebloom'].map(id => tracks[id]),
      similar: [
        { name:'reidenshi', art:'violetstatic' },
        { name:'Mooncircuit', art:'magenta' },
        { name:'Lune', art:'rosequartz' },
        { name:'Aris Pell', art:'slatebloom' },
      ],
      top: ['distorted','amberdusk','indigowave','magenta'].map((id, i) => ({ ...tracks[id], plays: ['48,2 M','12,9 M','9,1 M','7,4 M'][i] })),
    },
  };

  // — browser shortcuts —
  const shortcuts = [
    { name:'YouTube',    host:'youtube.com',    hue:'#FF0033' },
    { name:'SoundCloud', host:'soundcloud.com', hue:'#FF5500' },
    { name:'Vimeo',      host:'vimeo.com',      hue:'#17D5FF' },
    { name:'Instagram',  host:'instagram.com',  hue:'#E1306C' },
  ];

  window.DATA = { tracks, queue, library, playlists, downloads, discovery, shortcuts };
})();
