/* ============================================================
   chrome.jsx — fused frosted MiniPlayer + TabBar (single block).
   Tinted live by the current artwork's dominant colour.
   Exports: Chrome
   ============================================================ */

const TABS = [
  { id: 'browser',   label: 'Browser',     icon: 'globe',   fill: 'globeFill' },
  { id: 'library',   label: 'Bibliothèque',icon: 'library', fill: 'libraryFill' },
  { id: 'discovery', label: 'Découverte',  icon: 'compass', fill: 'compassFill' },
  { id: 'player',    label: 'Player',      icon: 'disc',    fill: 'discFill' },
];

function Chrome({ tab, onTab, track, playing, progress, onToggle, onNext, onPrev, onOpen, dlActive, miniProgress = true }) {
  const start = React.useRef(null);
  const down = (e) => { start.current = e.clientX; };
  const up = (e) => {
    if (start.current == null) return;
    const dx = e.clientX - start.current;
    if (dx < -45) { haptic('medium'); onNext(); }
    else if (dx > 45) { haptic('medium'); onPrev(); }
    else onOpen();
    start.current = null;
  };

  return (
    <div className="enter-sheet" style={{ position: 'absolute', left: 8, right: 8, bottom: 12, zIndex: 40 }}>
      <div className="glass" style={{
        borderRadius: 22, overflow: 'hidden',
        border: '0.5px solid var(--separator-op)',
        boxShadow: '0 10px 40px rgba(0,0,0,0.5)',
      }}>
        {/* dynamic tint overlay */}
        <div style={{ position: 'absolute', inset: 0,
          background: 'var(--dyn)', opacity: 0.32, mixBlendMode: 'soft-light',
          transition: 'background var(--dur-dyn) var(--ease)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', inset: 0,
          background: 'linear-gradient(var(--dyn-soft), transparent)', opacity: 0.45,
          transition: 'background var(--dur-dyn) var(--ease)', pointerEvents: 'none' }} />

        {/* mini-player */}
        {track && (
          <div onPointerDown={down} onPointerUp={up}
            style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 12px 10px', height: 64, cursor: 'pointer', touchAction: 'pan-y' }}>
            <Art id={track.art} size={44} radius={8} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--label)', whiteSpace: 'nowrap',
                overflow: 'hidden', textOverflow: 'ellipsis', letterSpacing: -0.2 }}>{track.title}</div>
              <div style={{ fontSize: 13, color: 'var(--label-2)', whiteSpace: 'nowrap', overflow: 'hidden',
                textOverflow: 'ellipsis' }}>{track.artist}</div>
            </div>
            <button className="press" onClick={(e) => { e.stopPropagation(); haptic('medium'); onToggle(); }}
              style={{ border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--label)', padding: 6 }}>
              <Icon name={playing ? 'pause' : 'play'} size={22} />
            </button>
            <button className="press" onClick={(e) => { e.stopPropagation(); haptic('medium'); onNext(); }}
              style={{ border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--label)', padding: 6 }}>
              <Icon name="forward" size={22} />
            </button>
            {/* 2px progress hugging bottom of mini-player */}
            {miniProgress && (
              <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 2, background: 'rgba(255,255,255,0.12)' }}>
                <div style={{ height: '100%', width: `${progress * 100}%`, background: 'var(--accent)',
                  transition: 'width .2s linear' }} />
              </div>
            )}
          </div>
        )}

        {/* tab bar */}
        <div style={{ position: 'relative', display: 'flex', padding: '8px 4px 9px',
          borderTop: track ? '0.5px solid var(--separator-op)' : 'none' }}>
          {TABS.map((t) => {
            const active = tab === t.id;
            return (
              <button key={t.id} className="press"
                onClick={() => { haptic('light'); onTab(t.id); }}
                style={{ flex: 1, border: 'none', background: 'transparent', cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '2px 0',
                  position: 'relative' }}>
                <div style={{ position: 'relative' }}>
                  <Icon name={active ? t.fill : t.icon} size={24}
                    color={active ? 'var(--accent)' : 'var(--label-2)'} sw={1.9} />
                  {t.id === 'library' && dlActive > 0 && (
                    <span style={{ position: 'absolute', top: -2, right: -6, minWidth: 8, height: 8,
                      borderRadius: 5, background: 'var(--accent)', boxShadow: '0 0 0 2px rgba(20,20,22,0.9)' }} />
                  )}
                </div>
                <span style={{ fontSize: 10, fontWeight: active ? 600 : 500,
                  color: active ? 'var(--accent)' : 'var(--label-2)', letterSpacing: -0.1 }}>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

window.Chrome = Chrome;
