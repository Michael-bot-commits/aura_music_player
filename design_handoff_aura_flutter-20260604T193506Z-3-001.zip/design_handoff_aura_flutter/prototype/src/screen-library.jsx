/* ============================================================
   screen-library.jsx — Bibliothèque (compact list + segmented)
   and Téléchargements (progress rings, grouped).
   Exports: LibraryScreen, DownloadsScreen, BigTitle
   ============================================================ */

function BigTitle({ title, children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between',
      padding: '6px 20px 14px' }}>
      <h1 style={{ margin: 0, fontSize: 32, fontWeight: 700, letterSpacing: -0.6, color: 'var(--label)' }}>{title}</h1>
      <div style={{ display: 'flex', gap: 6, paddingBottom: 4 }}>{children}</div>
    </div>
  );
}

function HeaderTool({ icon, onClick, badge }) {
  return (
    <button className="press" onClick={() => { haptic('light'); onClick && onClick(); }}
      style={{ width: 38, height: 38, borderRadius: '50%', border: 'none', background: 'var(--fill-3)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        color: 'var(--label)', position: 'relative' }}>
      <Icon name={icon} size={19} color="currentColor" sw={2} />
      {badge > 0 && <span style={{ position: 'absolute', top: 0, right: 0, minWidth: 16, height: 16, padding: '0 4px',
        borderRadius: 8, background: 'var(--accent)', color: '#fff', fontSize: 10, fontWeight: 700,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: '0 0 0 2px var(--bg)' }}>{badge}</span>}
    </button>
  );
}

function LibraryScreen({ playingId, onPlay, onMenu, onDownloads, dlActive }) {
  const [seg, setSeg] = React.useState('Tout');
  const { library, playlists } = window.DATA;

  let items = library;
  if (seg === 'Musique') items = library.filter((t) => t.kind === 'audio');
  if (seg === 'Vidéos') items = library.filter((t) => t.kind === 'video');

  return (
    <div className="noscroll" style={{ height: '100%', overflowY: 'auto', paddingBottom: 168 }}>
      <BigTitle title="Bibliothèque">
        <HeaderTool icon="download" onClick={onDownloads} badge={dlActive} />
        <HeaderTool icon="sort" />
        <HeaderTool icon="filter" />
      </BigTitle>

      <div style={{ padding: '0 16px 14px' }}>
        <Segmented items={['Tout', 'Musique', 'Vidéos', 'Playlists']} value={seg} onChange={setSeg} />
      </div>

      {seg !== 'Playlists' ? (
        <div>
          {items.map((t, i) => (
            <Cell key={t.id} track={t} onPlay={onPlay} onMenu={onMenu}
              playing={t.id === playingId} sep={i < items.length - 1} />
          ))}
        </div>
      ) : (
        <div>
          {/* create playlist */}
          <div className="press" style={{ display: 'flex', alignItems: 'center', gap: 14, height: 64,
            padding: '0 16px', cursor: 'pointer', position: 'relative' }}>
            <div style={{ width: 52, height: 52, borderRadius: 10, border: '1.5px dashed var(--accent)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)' }}>
              <Icon name="plus" size={22} />
            </div>
            <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--accent)' }}>Créer une playlist</span>
            <div style={{ position: 'absolute', left: 80, right: 0, bottom: 0, height: 0.5, background: 'var(--separator)' }} />
          </div>
          {playlists.map((p, i) => (
            <div key={p.id} className="press" style={{ display: 'flex', alignItems: 'center', gap: 14, height: 72,
              padding: '0 16px', cursor: 'pointer', position: 'relative' }}>
              <Mosaic arts={p.arts} size={52} radius={10} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--label)' }}>{p.name}</div>
                <div style={{ fontSize: 13, color: 'var(--label-2)', marginTop: 2 }}>{p.count} titres · {p.dur}</div>
              </div>
              <Icon name="chevronRight" size={16} color="var(--label-3)" />
              {i < playlists.length - 1 && <div style={{ position: 'absolute', left: 80, right: 0, bottom: 0, height: 0.5, background: 'var(--separator)' }} />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
function DLRow({ item, last }) {
  const sub = {
    downloading: item.fmt,
    queued: 'En attente de téléchargement',
    error: 'Échec — on réessaiera tout seul. Vérifie ta connexion.',
    done: item.fmt,
  }[item.state];
  const subColor = item.state === 'error' ? 'var(--accent)' : 'var(--label-2)';
  return (
    <div className="press" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
      cursor: item.state === 'error' ? 'pointer' : 'default', position: 'relative' }}>
      <Art id={item.art} size={40} radius={8} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--label)', whiteSpace: 'nowrap',
          overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.title}</div>
        <div style={{ fontSize: 12.5, color: subColor, marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden',
          textOverflow: 'ellipsis' }}>{sub}</div>
      </div>
      <Ring progress={item.progress} state={item.state} size={34} />
      {!last && <div style={{ position: 'absolute', left: 68, right: 0, bottom: 0, height: 0.5, background: 'var(--separator)' }} />}
    </div>
  );
}

function DownloadsScreen({ onBack }) {
  const { downloads } = window.DATA;
  return (
    <div className="noscroll" style={{ height: '100%', overflowY: 'auto', paddingBottom: 168 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '4px 12px 10px' }}>
        <IconBtn icon="chevronLeft" bare glyph={22} onClick={onBack} size={38} />
        <span style={{ fontSize: 17, fontWeight: 600, color: 'var(--label)' }}>Téléchargements</span>
      </div>
      <h1 style={{ margin: 0, padding: '0 20px 16px', fontSize: 30, fontWeight: 700, letterSpacing: -0.6, color: 'var(--label)' }}>En cours & terminés</h1>

      <SectionHeader>En cours · {downloads.active.length}</SectionHeader>
      <div style={{ marginBottom: 28 }}>
        {downloads.active.map((it, i) => <DLRow key={it.id} item={it} last={i === downloads.active.length - 1} />)}
      </div>

      <SectionHeader>Terminés · {downloads.done.length}</SectionHeader>
      <div>
        {downloads.done.map((it, i) => <DLRow key={it.id} item={it} last={i === downloads.done.length - 1} />)}
      </div>
    </div>
  );
}

Object.assign(window, { LibraryScreen, DownloadsScreen, BigTitle, HeaderTool });
