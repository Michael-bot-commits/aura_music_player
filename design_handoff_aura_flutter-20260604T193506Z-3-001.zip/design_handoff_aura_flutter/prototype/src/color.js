/* ============================================================
   color.js — live dominant-colour extraction from artwork.
   draws the cover to a small offscreen canvas, buckets pixels
   into a coarse histogram weighted by saturation, returns the
   dominant hue + legibility-corrected companions for the player
   ambient wash / chrome tint.
   window.AuraColor.extract(imgEl) -> { dom, soft, glow, raw }
   ============================================================ */
(function () {
  const cv = document.createElement('canvas');
  const N = 48;                 // sample resolution
  cv.width = N; cv.height = N;
  const cx = cv.getContext('2d', { willReadFrequently: true });

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0; const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        default: h = (r - g) / d + 4;
      }
      h /= 6;
    }
    return [h, s, l];
  }
  function hslToRgb(h, s, l) {
    let r, g, b;
    if (s === 0) { r = g = b = l; }
    else {
      const hue2rgb = (p, q, t) => {
        if (t < 0) t += 1; if (t > 1) t -= 1;
        if (t < 1/6) return p + (q - p) * 6 * t;
        if (t < 1/2) return q;
        if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
        return p;
      };
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = hue2rgb(p, q, h + 1/3); g = hue2rgb(p, q, h); b = hue2rgb(p, q, h - 1/3);
    }
    return [Math.round(r*255), Math.round(g*255), Math.round(b*255)];
  }
  const css = (a) => `rgb(${a[0]},${a[1]},${a[2]})`;

  function extract(img) {
    try {
      cx.clearRect(0, 0, N, N);
      cx.drawImage(img, 0, 0, N, N);
      const data = cx.getImageData(0, 0, N, N).data;
      // bucket hue into 24 bins; track summed saturation*weight & avg l
      const bins = 24;
      const acc = Array.from({ length: bins }, () => ({ w: 0, h: 0, s: 0, l: 0 }));
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i], g = data[i+1], b = data[i+2];
        const [h, s, l] = rgbToHsl(r, g, b);
        if (l < 0.06 || l > 0.96) continue;        // skip near-black/white
        const bi = Math.min(bins - 1, Math.floor(h * bins));
        const w = s * s + 0.05;                     // saturation-weighted
        acc[bi].w += w; acc[bi].h += h * w; acc[bi].s += s * w; acc[bi].l += l * w;
      }
      let best = null;
      for (const a of acc) if (a.w > 0 && (!best || a.w > best.w)) best = a;
      if (!best) best = { w: 1, h: 0, s: 0.1, l: 0.3 };
      const h = best.h / best.w, s = best.s / best.w, l = best.l / best.w;

      // dominant — vivid but controlled
      const dom  = hslToRgb(h, Math.min(0.72, Math.max(0.4, s)), Math.min(0.5, Math.max(0.32, l)));
      // ambient wash — darkened & slightly desaturated for legibility
      const soft = hslToRgb(h, Math.min(0.5, s * 0.7), 0.14);
      const glow = hslToRgb(h, Math.min(0.8, s + 0.1), Math.min(0.55, l + 0.05));

      return {
        dom: css(dom),
        soft: css(soft),
        glow: `rgba(${glow[0]},${glow[1]},${glow[2]},0.55)`,
        raw: { h, s, l },
      };
    } catch (e) {
      return { dom: '#3a3a40', soft: '#1a1a1e', glow: 'rgba(120,120,140,0.4)', raw: null };
    }
  }

  // load an image (data URL) then extract
  function fromSrc(src) {
    return new Promise((resolve) => {
      const im = new Image();
      im.onload = () => resolve(extract(im));
      im.onerror = () => resolve({ dom:'#3a3a40', soft:'#1a1a1e', glow:'rgba(120,120,140,0.4)', raw:null });
      im.src = src;
    });
  }

  window.AuraColor = { extract, fromSrc };
})();
