# PROMPT — INGÉNIEUR FLUTTER SENIOR : AURA MEDIA PLAYER
# Application tout-en-un · Flutter / Dart · iOS-first · VSCode / Ubuntu

---

## RÔLE ET CONTEXTE

Tu es un ingénieur Flutter senior. Tu vas intégrer et compléter
l'application AURA Media Player en partant du design handoff fourni
dans ce dossier.

Environnement de développement : **VSCode sur Ubuntu**
Cible principale : **iOS** (et Android en second lieu)

Ce projet est en deux parties :
- PARTIE 1 (ce prompt) → app Flutter complète
- PARTIE 2 (prompt séparé) → backend Python / FastAPI / yt-dlp

Tu dois à tout moment :
- Utiliser les fichiers Dart de `flutter/lib/` comme blueprint
- Comparer chaque écran contre `screenshots/` et le prototype HTML
- Respecter TOUS les tokens définis dans `lib/theme/tokens.dart`
- Ne JAMAIS redesigner — reproduire pixel-for-pixel ce qui est défini
- Construire en phases validées — ne pas sauter d'étapes

---

## COMMANDES DE DÉMARRAGE (Ubuntu / VSCode)

```bash
# Créer le projet Flutter
flutter create aura_media_player --org com.tonnom --platforms ios,android
cd aura_media_player

# Copier les fichiers du handoff
cp -r path/to/design_handoff_aura_flutter/flutter/lib/ lib/
cp path/to/design_handoff_aura_flutter/flutter/pubspec.yaml .

# Créer le dossier artwork
mkdir -p assets/artwork

# Installer les dépendances
flutter pub get

# Vérifier l'installation Flutter
flutter doctor

# Lancer sur simulateur iOS (si Xcode installé) ou Android
flutter run
```

---

## DÉPENDANCES — pubspec.yaml

```yaml
dependencies:
  flutter:
    sdk: flutter
  provider: ^6.1.2          # state management
  google_fonts: ^6.2.1      # Inter (SF Pro substitute)
  palette_generator: ^0.3.3 # extraction couleur dominante
  path_drawing: ^1.0.1      # rendu SVG icons pixel-identiques

  # À ajouter pour la vraie lecture audio (étape 3)
  just_audio: ^0.9.36
  audio_session: ^0.1.18
  just_audio_background: ^0.0.1-beta.10

  # À ajouter pour la lecture vidéo (étape 3)
  video_player: ^2.8.2

  # À ajouter pour le browser intégré (étape 8)
  webview_flutter: ^4.7.0

  # À ajouter pour le stockage local (étape 7)
  sqflite: ^2.3.2
  path: ^1.9.0

  # À ajouter pour les requêtes réseau (étape 10)
  http: ^1.2.1
  cached_network_image: ^3.3.1

flutter:
  uses-material-design: true
  assets:
    - assets/artwork/
```

---

## IDENTITÉ VISUELLE — AURA (NE PAS MODIFIER)

> Source de vérité absolue : `lib/theme/tokens.dart`

### Couleur accent (brand)
```dart
static const accent = Color(0xFFFF6E72);      // Coral dark
static const accentDeep = Color(0xFFFF5A5F);  // Coral base
```
UNE seule couleur accent dans toute l'app — jamais d'autre.

### Surfaces (dark-first)
```dart
static const bg  = Color(0xFF000000);   // fond principal
static const bg2 = Color(0xFF1C1C1E);   // fond secondaire (sheets)
static const bg3 = Color(0xFF2C2C2E);   // fond tertiaire (inputs)
```

### Labels
```dart
static const label  = Color(0xFFFFFFFF);
static const label2 = Color(0x99EBEBF5);  // 60%
static const label3 = Color(0x4DEBEBF5);  // 30%
static const label4 = Color(0x2EEBEBF5);  // 18%
```

### Status
```dart
static const success = Color(0xFF30D158);
static const error   = Color(0xFFFF453A);
static const warning = Color(0xFFFF9F0A);
```

### Couleur dynamique (mécanique signature AURA)
`DynamicColor` (ChangeNotifier) extrait la couleur dominante via
`palette_generator`. Publie `dominant` + `ambient`.
RootShell appelle `dyn.update(artProvider(art), art)` à chaque
changement de piste. Chrome et player lisent
`context.watch<DynamicColor>()` et crossfadent avec
`AnimatedContainer` sur `Motion.dynamicColor` (600ms).
**Ne pas modifier `lib/core/dynamic_color.dart`.**

### Typographie — Inter via google_fonts
```dart
// Display / grands titres (28–34 Bold, tracking −0.5)
static TextStyle display([double size = 28])

// Track title (17 Semibold)
static final trackTitle

// Subtitle (15 Regular, label2)
static final subtitle

// Section header (13 Semibold, UPPERCASE, label2)
static final sectionHeader

// Meta small (12.5 Regular, label2)
static final metaSmall

// Timestamp (Roboto Mono 12 Regular)
static final timestamp
```

### Radii
```dart
class R {
  static const xs  = 8.0;   // artwork cellules, petites vignettes
  static const sm  = 10.0;
  static const md  = 12.0;  // cartes, grille, boutons
  static const art = 15.0;  // artwork player plein écran
  static const lg  = 20.0;  // sheets, chrome fusionné
  static const xl  = 28.0;
  static const pill = 999.0;
}
```

### Espacements (grille base-4)
```dart
class Space {
  static const xxs = 4.0;
  static const xs  = 8.0;
  static const sm  = 12.0;
  static const md  = 16.0;  // marge latérale standard
  static const lg  = 20.0;  // grands titres
  static const xl  = 28.0;
}
```

### Motion
```dart
class Motion {
  static const fast         = Duration(milliseconds: 160);
  static const base         = Duration(milliseconds: 240);
  static const dynamicColor = Duration(milliseconds: 600);
  static const ease    = Cubic(0.32, 0.72, 0, 1);
  static const easeOut = Cubic(0.22, 1, 0.36, 1);
  static const spring  = Cubic(0.34, 1.2, 0.64, 1);  // artwork scale
}
```
Pas de bounce · Pas de boucles décoratives infinies.

### Élévation et matériaux
```dart
// Frosted glass = BackdropFilter(ImageFilter.blur) + fill translucide
class Glass {
  static const blurSigma = 18.0;
  static const fill     = Color(0x8C28282C);  // rgba(40,40,44,0.55)
  static const fillThin = Color(0x6B3C3C42);
}

// Une seule ombre dans tout le système — artwork uniquement
const artworkShadow = [
  BoxShadow(color: Color(0x73000000), blurRadius: 30, offset: Offset(0, 10)),
];
```

### Iconographie — AppIcon custom (lib/widgets/icons.dart)
`AppIcon('name', size:…, color:…)` — rendu SVG identique au prototype.
Glyphes outline → stroked · Glyphes `*Fill` → filled (états actifs).
**Ne pas modifier icons.dart — les paths SVG sont la source de vérité.**

### Interactions et haptiques
```dart
// Press state = scale(0.96) sur tout contrôle — via Pressable()
// Haptic léger → tap standard
// Haptic moyen → changement piste / action primaire
// Haptic success/error → téléchargements
// Zones tactiles minimum → 44×44pt
```

---

## FICHIERS FOURNIS — NE PAS REDESIGNER, INTÉGRER

Tous ces fichiers sont dans `flutter/lib/` — ils sont le blueprint.
Ton rôle est de les intégrer dans un vrai projet Flutter,
corriger les détails de compilation, et câbler la vraie logique.

| Fichier | Rôle |
|---|---|
| `main.dart` | Entry + RootShell · démarrer ici |
| `theme/tokens.dart` | Tous les tokens · NE PAS MODIFIER |
| `core/dynamic_color.dart` | Extraction couleur dominante · NE PAS MODIFIER |
| `data/models.dart` | Track, Playlist, DownloadItem, etc. |
| `data/player_model.dart` | Playback state (ChangeNotifier) |
| `data/store.dart` | Catalogue sample → remplacer |
| `widgets/icons.dart` | AppIcon SVG custom · NE PAS MODIFIER |
| `widgets/artwork.dart` | Artwork + Mosaic |
| `widgets/buttons.dart` | Pressable, PrimaryButton, SecondaryButton, GlassIconButton |
| `widgets/common.dart` | TrackCell, SectionHeader, Segmented, SearchField, Toast |
| `widgets/scrubber.dart` | Scrubber audio (4pt track / 11pt thumb) |
| `widgets/progress_ring.dart` | ProgressRing téléchargement |
| `screens/chrome.dart` | FusedChrome (MiniPlayer + TabBar) |
| `screens/player_screen.dart` | Player plein écran |
| `screens/player_subviews.dart` | LyricsView + QueueView |
| `screens/library_screen.dart` | Bibliothèque + HeaderTool |
| `screens/downloads_screen.dart` | Téléchargements |
| `screens/browser_screen.dart` | Browser + InterceptSheet |
| `screens/discovery_screen.dart` | Découverte + ArtistPageView |

---

## STRUCTURE DU PROJET FLUTTER

```
aura_media_player/
├── pubspec.yaml
├── lib/
│   ├── main.dart                    ← depuis flutter/lib/ (entry)
│   ├── theme/
│   │   └── tokens.dart              ← NE PAS MODIFIER
│   ├── core/
│   │   ├── dynamic_color.dart       ← NE PAS MODIFIER
│   │   ├── audio_manager.dart       ← À CRÉER : just_audio
│   │   ├── background_audio.dart    ← À CRÉER : audio_session
│   │   └── now_playing.dart         ← À CRÉER : Control Center iOS
│   ├── data/
│   │   ├── models.dart              ← depuis flutter/lib/
│   │   ├── player_model.dart        ← depuis flutter/lib/
│   │   ├── store.dart               ← depuis flutter/lib/ (remplacer)
│   │   └── database.dart            ← À CRÉER : sqflite
│   ├── widgets/
│   │   ├── icons.dart               ← NE PAS MODIFIER
│   │   ├── artwork.dart             ← depuis flutter/lib/
│   │   ├── buttons.dart             ← depuis flutter/lib/
│   │   ├── common.dart              ← depuis flutter/lib/
│   │   ├── scrubber.dart            ← depuis flutter/lib/
│   │   └── progress_ring.dart       ← depuis flutter/lib/
│   ├── screens/
│   │   ├── chrome.dart              ← depuis flutter/lib/
│   │   ├── player_screen.dart       ← depuis flutter/lib/
│   │   ├── player_subviews.dart     ← depuis flutter/lib/
│   │   ├── library_screen.dart      ← depuis flutter/lib/
│   │   ├── downloads_screen.dart    ← depuis flutter/lib/
│   │   ├── browser_screen.dart      ← depuis flutter/lib/
│   │   └── discovery_screen.dart    ← depuis flutter/lib/
│   └── services/
│       ├── backend_service.dart     ← À CRÉER
│       ├── download_manager.dart    ← À CRÉER
│       ├── deezer_service.dart      ← À CRÉER
│       ├── soundcloud_service.dart  ← À CRÉER
│       ├── jamendo_service.dart     ← À CRÉER
│       ├── lastfm_service.dart      ← À CRÉER
│       ├── musicbrainz_service.dart ← À CRÉER
│       ├── genius_service.dart      ← À CRÉER
│       └── lrclib_service.dart      ← À CRÉER
├── assets/
│   └── artwork/
│       └── [distorted.jpg, nightswim.jpg, ...]
└── test/
```

---

## CONFIGURATION iOS (Runner/Info.plist)

```xml
<!-- Background audio -->
<key>UIBackgroundModes</key>
<array>
  <string>audio</string>
  <string>fetch</string>
</array>

<!-- Accès aux fichiers locaux -->
<key>NSDocumentsFolderUsageDescription</key>
<string>AURA accède à vos fichiers pour enrichir votre bibliothèque.</string>

<!-- WebView (si inline browser) -->
<key>NSAppTransportSecurity</key>
<dict>
  <key>NSAllowsArbitraryLoads</key><true/>
</dict>
```

### android/app/src/main/AndroidManifest.xml
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
```

---

## ÉCRANS — COMPORTEMENT ATTENDU ET RÉFÉRENCE VISUELLE

> Comparer systématiquement avec `screenshots/` et le prototype HTML.

### ÉCRAN 1 — Chrome fusionné (MiniPlayer + TabBar)
**Fichier** : `screens/chrome.dart` · **Ref** : `screenshots/05-chrome.png`

Bloc frosted flottant unique (radius 22) :
- `BackdropFilter(ImageFilter.blur(sigmaX: 24, sigmaY: 24))`
- Fill `Glass.fill` + border `AppColors.separatorOp`
- Overlay `AnimatedContainer` avec `dyn.ambient.withOpacity(0.45)`
  en gradient top → transparent (crossfade 600ms)

Mini-player (64pt) :
- Artwork 44pt · titre + artiste (1 ligne) · pause · forward
- Barre de progression 2pt accent hugging le bas
- GestureDetector onTap → openPlayer · onHorizontalDragEnd → next/prev

TabBar (4 tabs) :
- Browser · Bibliothèque · Découverte · Player
- Actif → icon `*Fill` + tint accent
- Dot accent 8pt sur Bibliothèque si downloadsBadge > 0

Padding : `EdgeInsets.fromLTRB(8, 0, 8, 12)`
Positionné via `Positioned(bottom: MediaQuery.padding.bottom)`

### ÉCRAN 2 — Player plein écran
**Fichiers** : `screens/player_screen.dart` + `player_subviews.dart`
**Ref** : `screenshots/03-player.png`

Background (superposition) :
1. `AnimatedSwitcher` + Image artwork · crossfade sur track change
2. `BackdropFilter(ImageFilter.blur(sigmaX: 34, sigmaY: 34))`
3. `AnimatedContainer` `dyn.ambient.withOpacity(0.5)`
4. `LinearGradient` : noir 0.45 → 0.2 → 0.55 → 0.86

Header : `chevronDown` · contexte centré · `ellipsis`

Région centre — 3 états (CentreView) :
- `cover` → `AnimatedScale` 1.0↔0.82 play/pause (Motion.spring)
  Artwork radius R.art · `artworkShadow`
- `lyrics` → LyricsView (ligne active = white, autres 0.32–0.4)
- `queue` → QueueView

Titre : Display 27 + artiste 17pt opacity 0.62 + heart toggle

Scrubber : 4pt track · 11pt thumb (15pt drag) + timestamps mono

Transport (5 boutons) :
- shuffle · backward · **play/pause 70pt cercle blanc** · forward · repeat
- shuffle/repeat → active = tint accent

Volume : speakerLow · Scrubber track white 0.2 · speakerHigh

Footer tabs : Paroles (quote) · airplay · File d'attente (queue)

Présenté via `showModalBottomSheet` avec `heightFactor: 1`

### ÉCRAN 3 — Bibliothèque
**Fichier** : `screens/library_screen.dart`
**Ref** : `screenshots/01-library.png`

Header :
- "Bibliothèque" Display 32 tracking -0.6
- 3 HeaderTool (38pt cercle bg3) :
  `download` (badge = downloadsBadge) · `sort` · `filter`

Segmented control custom :
- Tout · Musique · Vidéos · Playlists
- Thumb animé `AnimatedPositioned` (Motion.base, Motion.ease)

Liste (Tout / Musique / Vidéos) :
- TrackCell 64pt : artwork 52pt · titre · artiste · durée · ellipsis
- Séparateur hairline `AppColors.separator 0.5pt`
- Badge `video` sur artwork vidéo
- Titre tint accent si piste en cours

Playlists :
- "Créer une playlist" : border dashed accent
- Mosaic 52pt (4 artworks) · nom · count + durée · chevronRight

Downloads → `Navigator.push(MaterialPageRoute(DownloadsScreen))`

### ÉCRAN 4 — Downloads
**Fichier** : `screens/downloads_screen.dart`
**Ref** : `screenshots/04-downloads.png`

Sections "EN COURS · N" / "TERMINÉS · N"
Row : artwork 40pt · titre · détail · ProgressRing 34pt
États : queued (gris + clock) · downloading (arc accent + %) ·
        done (checkCircle vert) · error (errorCircle coral)
Message erreur : "Échec — on réessaiera tout seul. Vérifie ta connexion."

### ÉCRAN 5 — Browser
**Fichier** : `screens/browser_screen.dart`
**Ref** : `screenshots/06-browser.png` + `07-intercept.png`

Nav bar custom :
- arrowLeft · arrowRight · capsule URL (lock 12pt + texte 14pt) ·
  refresh · homeFill (tint accent)
- Capsule height 38 · fond bg3

Home :
- Grille 4 colonnes raccourcis (YouTube · SoundCloud · Vimeo · Instagram)
  → tiles carrés avec lettre initiale + fond teinté hue source
- Section "Récemment visités" en liste

WKWebView / webview_flutter (étape 8) :
- WebViewController avec injection JavaScript
- Détection `<video>` et `<audio>` qui commencent à jouer
- Déclencher InterceptSheet

InterceptSheet (`showModalBottomSheet` height ~300pt) :
- "DÉTECTÉ · {SOURCE}" accent 12pt bold
- Artwork 56pt · titre 18pt · artiste 14pt
- PrimaryButton "Lire maintenant"
- Row SecondaryButton "Audio" + "Vidéo"
- Lien tertiaire "Partager le lien"
- Drag indicator + `presentationDragIndicator` équivalent

### ÉCRAN 6 — Découverte
**Fichier** : `screens/discovery_screen.dart`
**Ref** : `screenshots/02-discovery.png` + `08-discovery-results.png` + `09-artist.png`

État vide :
- "Découverte" Display 32 tracking -0.6
- SearchField capsule (search + mic)
- Chips "Recherches récentes" scroll horizontal
- Carousel "Tendances" 150pt avec badge rang
- Bulles artistes populaires 92pt circulaires

État résultats :
- Groupés par source : Deezer · SoundCloud · Jamendo
- SectionHeader + "Tout voir ›"
- `_StaggeredItem` (fade + rise, délai 50ms entre items)
- Ellipsis → `showModalBottomSheet` options :
  Aperçu 30s · YouTube Music · Télécharger audio · Télécharger vidéo

Page artiste :
- Header parallax 320pt via `ScrollController` + `Transform.translate`
  offset = `_offset * 0.4` + `Transform.scale(1.1)`
- Gradient noir 0.4 → transparent → bg
- Nom Display 38 tracking -0.8
- Boutons Lire (PrimaryButton) · Shuffle · Plus (SecondaryButton 48pt)
- Bio expandable (3 lignes → "Lire la suite" accent)
- Titres populaires avec rang + plays
- Discographie grille 3 colonnes
- Artistes similaires scroll horizontal 80pt
- Back button `GlassIconButton('chevronLeft')`

---

## CÂBLAGE AUDIO RÉEL — just_audio

> PlayerModel a actuellement un Timer qui simule la lecture.
> Remplacer par just_audio.

### lib/core/audio_manager.dart (à créer)
```dart
// Responsabilités :
// - AudioPlayer (just_audio)
// - AudioSession configuration (.music category)
// - playerStateStream → PlayerModel.isPlaying
// - positionStream toutes 500ms → PlayerModel.progress
// - processingStateStream → next() quand completed
// - Méthode seek(Duration)
// - Support : MP3, AAC, M4A, FLAC, WAV
// - Fichiers locaux : AudioSource.uri(Uri.file(path))
// - Streams URL : AudioSource.uri(Uri.parse(url))
// - Pour vidéo en mode audio : just_audio extrait la piste audio

// Initialisation :
final player = AudioPlayer();
final session = await AudioSession.instance;
await session.configure(AudioSessionConfiguration.music());
```

### lib/core/background_audio.dart (à créer)
```dart
// just_audio_background pour la lecture en arrière-plan :
// - Audio continue quand écran verrouillé
// - Audio continue quand l'app est en arrière-plan
// - Intégration Control Center iOS automatique via just_audio_background
// Initialiser dans main() avant runApp()
```

### lib/core/now_playing.dart (à créer)
```dart
// just_audio_background gère MediaItem automatiquement.
// Enrichir avec :
// - MediaItem(id, title, artist, artUri, duration)
// - Artwork via artProvider(key) converti en Uri fichier local
// Commandes distantes : play/pause/next/previous/seek
// → gérées automatiquement par just_audio_background
```

---

## COMMUNICATION AVEC LE BACKEND PYTHON

> Le backend Python n'existe pas encore.
> Préparer la couche réseau sans en dépendre.

### lib/services/backend_service.dart (à créer)
URL de base configurable : `http://localhost:8000`
(Récupérer depuis SharedPreferences dans les Settings)

```dart
// Endpoints :

// POST /download
// Body: { "url": String, "format": "audio"|"video", "quality": "best" }
// Response: { "task_id": String, "status": "queued" }

// GET /download/status/{task_id}
// Response: {
//   "task_id": String,
//   "status": "queued"|"downloading"|"complete"|"error",
//   "progress": double (0-100),
//   "filename": String,
//   "file_url": String,
//   "thumbnail_url": String,
//   "metadata": { "title": String, "artist": String, "duration": int }
// }

// GET /files/{filename}    → bytes audio ou vidéo
// GET /thumbnails/{filename} → bytes image JPEG
// GET /health              → { "status": "ok", "yt_dlp_version": String }
```

### lib/services/download_manager.dart (à créer)
```dart
// Queue de téléchargements (ChangeNotifier)
// Poll GET /download/status/{id} toutes les 2 secondes
// À 'complete' :
//   → GET /files/{filename} → sauvegarder dans app documents
//   → GET /thumbnails/{filename} → sauvegarder comme artwork
//   → Créer Track dans database.dart
//   → Notifier PlayerModel de la nouvelle bibliothèque
//   → Notification locale
// Si backend inaccessible → DownloadState.error + message non technique
// Mettre à jour DataStore.downloadsBadge → badge TabBar
```

---

## SERVICES EXTERNES — APIS GRATUITES

### Logique de priorité pour les pochettes
```
1. MusicBrainz + Cover Art Archive → pochette officielle
   https://musicbrainz.org/ws/2/recording?query={artist}+{title}&fmt=json
   https://coverartarchive.org/release/{id}/front

2. Miniature YouTube (si source == youtube)
   → fournie dans les métadonnées du backend (thumbnail_url)

3. Placeholder généré localement
   → initiale artiste sur fond coloré (via Artwork errorBuilder)
```

### lib/services/deezer_service.dart
```dart
// Base: https://api.deezer.com
// GET /search?q={query} → titres + métadonnées + preview 30s URL
// GET /artist/{id} → photo + bio
// GET /album/{id}/tracks → tracklist complète
// Pas de clé API requise pour les endpoints publics
```

### lib/services/soundcloud_service.dart
```dart
// API publique SoundCloud
// Recherche + lecture titres publics
// Client ID requis (obtenir sur developers.soundcloud.com)
```

### lib/services/jamendo_service.dart
```dart
// Base: https://api.jamendo.com/v3.0
// GET /tracks/?client_id={id}&search={query}
// Lecture ET téléchargement 100% légaux (Creative Commons)
// Client ID gratuit sur developer.jamendo.com
```

### lib/services/lastfm_service.dart
```dart
// Base: https://ws.audioscrobbler.com/2.0/
// method=artist.getinfo → biographie
// method=artist.getsimilar → artistes similaires
// API key requise (gratuit sur last.fm/api)
```

### lib/services/musicbrainz_service.dart
```dart
// Base: https://musicbrainz.org/ws/2/
// Pas de clé API requise
// Cache via cached_network_image
```

### lib/services/lrclib_service.dart + genius_service.dart
```dart
// LRCLIB (priorité, paroles synchronisées) :
// GET https://lrclib.net/api/get?artist_name={a}&track_name={t}
// → { syncedLyrics: "[00:12.00] ligne..." }

// Genius (fallback, paroles statiques) :
// GET https://api.genius.com/search?q={artist}+{title}
// API key gratuite sur genius.com/api-clients
```

---

## BASE DE DONNÉES LOCALE — sqflite

### lib/data/database.dart (à créer)
```dart
// Tables SQLite :
//
// tracks :
//   id TEXT PRIMARY KEY, title TEXT, artist TEXT, album TEXT,
//   duration INTEGER, kind TEXT, art TEXT, file_path TEXT,
//   stream_url TEXT, artwork_path TEXT, source TEXT,
//   download_date INTEGER, play_count INTEGER,
//   last_played INTEGER, lyrics TEXT, genre TEXT, year INTEGER
//
// playlists :
//   id TEXT PRIMARY KEY, name TEXT, created_at INTEGER
//
// playlist_tracks :
//   playlist_id TEXT, track_id TEXT, position INTEGER
```

---

## ORDRE D'IMPLÉMENTATION — 14 ÉTAPES

Implémenter strictement dans cet ordre.
Valider chaque étape avant de passer à la suivante.

```
Étape 1 — Setup projet Flutter dans VSCode
  flutter create · copier lib/ · flutter pub get
  Créer assets/artwork/ · ajouter images placeholder
  Corriger erreurs de compilation sans modifier les tokens
  Valider : flutter run compile et affiche les 4 tabs

Étape 2 — Intégrer les fichiers design fournis
  Copier tous les fichiers de flutter/lib/ dans lib/
  Corriger imports manquants et types
  NE PAS modifier tokens, couleurs, comportements visuels
  Comparer visuellement avec screenshots/

Étape 3 — Câbler just_audio au PlayerModel
  Créer audio_manager.dart
  Remplacer le Timer par just_audio streams
  playerStateStream → PlayerModel.isPlaying
  positionStream → PlayerModel.progress
  Tester : lecture fichier local, progression temps réel

Étape 4 — Background audio + Control Center iOS
  Ajouter just_audio_background dans pubspec.yaml
  Créer background_audio.dart
  Initialiser dans main() avant runApp()
  Configurer Info.plist (UIBackgroundModes: audio)
  Tester : verrouiller écran → audio continue
  Tester : Control Center affiche pochette et contrôles

Étape 5 — Valider player plein écran
  Tous les éléments câblés avec vrai PlayerModel
  AnimatedScale play/pause fonctionne
  AnimatedSwitcher backdrop crossfade sur changement piste
  DynamicColor mis à jour correctement

Étape 6 — Bibliothèque locale réelle
  Lire fichiers audio/vidéo dans app documents
  Lire bibliothèque musicale iOS via just_audio
  Alimenter LibraryScreen avec données réelles
  Lecture au tap sur une TrackCell

Étape 7 — Base de données sqflite
  Créer database.dart (Track + Playlist)
  Remplacer progressivement DataStore
  Persistance entre sessions
  Tester : fermer / rouvrir → bibliothèque toujours là

Étape 8 — BrowserScreen avec webview_flutter réel
  Remplacer la simulation par WebViewController
  Injection JavaScript pour détecter <video> et <audio>
  InterceptSheet déclenché par vraie détection
  Tester : YouTube → lancer vidéo → popup apparaît

Étape 9 — BackendService + DownloadManager
  backend_service.dart avec tous les endpoints
  download_manager.dart avec queue et polling 2s
  Gestion d'erreur si backend inaccessible
  ProgressRing avec vrais états
  Badge TabBar mis à jour

Étape 10 — Deezer API
  deezer_service.dart
  Brancher DiscoveryScreen à Deezer (remplacer groupedResults)
  Aperçu 30s déclenché depuis les résultats
  Fiche artiste avec vraies données

Étape 11 — SoundCloud + Jamendo + Last.fm
  Résultats groupés multi-sources dans DiscoveryScreen
  Lecture complète contenu public SoundCloud
  Téléchargement contenu libre Jamendo
  Biographies + artistes similaires Last.fm

Étape 12 — Pochettes automatiques
  musicbrainz_service.dart
  Logique priorité MusicBrainz → miniature YouTube → placeholder
  cached_network_image pour cache automatique
  Artwork dans Control Center mis à jour

Étape 13 — Paroles
  lrclib_service.dart (paroles synchronisées)
  genius_service.dart (fallback statique)
  LyricsView câblé avec vraies paroles
  Masquer tab Paroles si rien trouvé

Étape 14 — Polish et stabilisation
  Mode offline : lecture locale sans réseau
  Messages d'erreur non techniques partout
  Animations vérifiées contre le prototype HTML
  Tests sur simulateur iOS
  Tests sur appareil Android
```

---

## CONTRAINTES ABSOLUES

```
✅ Flutter pur, dépendances minimales listées dans pubspec.yaml
✅ Provider pour state management
✅ Dark-first (AppColors constants)
✅ Zones tactiles ≥ 44×44pt (via Pressable + GestureDetector)
✅ BackdropFilter pour le frosted glass (chrome + sheets)
✅ Une seule ombre → artworkShadow sur artwork uniquement
✅ Une seule couleur accent → AppColors.accent partout
✅ Toute interaction a son Pressable (scale 0.96)
✅ Toute interaction a son haptic approprié

❌ NE PAS modifier tokens.dart
❌ NE PAS modifier dynamic_color.dart
❌ NE PAS modifier icons.dart
❌ NE PAS utiliser MusicKit (pas dans ce projet)
❌ NE PAS hardcoder l'URL du backend
❌ NE PAS redesigner les écrans fournis
❌ NE PAS créer de fichiers > 400 lignes
❌ NE PAS ignorer les erreurs réseau sans état visuel clair
❌ NE PAS avancer à l'étape N+1 sans valider l'étape N
```

---

## RAPPEL — PARTIE 2 DU PROJET

Ce prompt couvre uniquement la partie Flutter.
Une fois la partie Flutter stable, un second prompt couvrira :
- Le backend Python + FastAPI
- yt-dlp et l'extraction audio/vidéo
- Les endpoints définis dans backend_service.dart
- La configuration Tailscale pour accès mobile

Le code Flutter doit fonctionner en mode dégradé si le backend
est inaccessible : lecture locale et découverte via APIs restent
disponibles, les téléchargements affichent un message clair.
